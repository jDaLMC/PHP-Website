<?php 
 $con = mysqli_connect("localhost","root","","oceangate");
 session_start();
	if(isset($_POST["quantity"])&&!isset($_GET['action'])) {
		$productByCode = $con->query("SELECT * FROM product WHERE productid='".$_POST["id"]. "'");
		$productArray=mysqli_fetch_assoc($productByCode);

		while ($productByCode = array($productArray)) {
			$itemArray = array($productByCode[0]["productid"]=>array('name'=>$productByCode[0]["name"], 'productid'=>$productByCode[0]["productid"], 'quantity'=>$_POST["quantity"], 'description'=>$productByCode[0]["description"], 'price'=>$productByCode[0]["price"], 'image'=>$productByCode[0]["imgurl"]));

			if(!empty($_SESSION["cart_item"])) {
			if(in_array($productByCode[0]["productid"],array_keys($_SESSION["cart_item"]))) {
				foreach($_SESSION["cart_item"] as $k => $v) {
					$item_id = $_POST['id'];
						if($v["productid"] == $item_id) {
							$_SESSION["cart_item"][$k]["quantity"] += $_POST["quantity"];
						}
				}
			} else {
				$_SESSION["cart_item"] = array_merge($_SESSION["cart_item"],$itemArray);
			}
		} else {
			$_SESSION["cart_item"] = $itemArray;
		} break;
		}
	} 
		header("location:../view/checkout.php");
?>