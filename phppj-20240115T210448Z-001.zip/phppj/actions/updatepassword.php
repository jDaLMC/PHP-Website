<?php 
	$oldpass = $_POST['oldpass'];
	$newpass = $_POST['newpass'];
	$repass = $_POST['repass'];
	$id = $_POST['id'];

	$con = mysqli_connect("localhost","root","","oceangate");
	$sqlcheck = "SELECT * FROM customer WHERE customerid='".$id."'";
	$checkpass = $con->query($sqlcheck);
	$check=$checkpass->fetch_assoc();

	if ($oldpass == $check["password"]) {
		$update = "UPDATE customer SET password='".$newpass."' WHERE customerid='".$id."'";
		$con->query($update);
		header("location:../view/userprofile.php?update=true");
	}
	else{
		header("location:../view/userprofile.php?oldpass=wrong");

	}



?>