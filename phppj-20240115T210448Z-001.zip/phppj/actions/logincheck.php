<?php
    session_start();
    $conn = mysqli_connect("localhost", "root","", "oceangate");
    if (isset($_POST["email"])) {		
        $email = $_POST['email'];
        $password = $_POST['password'];
        
        $sql = "SELECT * FROM customer WHERE email='".$email."' AND password='".$password."' ";
        $count = $conn->query($sql)->num_rows;
        
        $sqladmin = "SELECT * FROM admin WHERE email='".$email."' AND password='".$password."' ";
        $countadmin = $conn->query($sqladmin)->num_rows;
        $un = $conn->query($sql);
        $username = $un->fetch_assoc();

        $adminname = $conn->query($sqladmin);
        $admin=$adminname->fetch_assoc();
        if ($count > 0){
            $_SESSION['username'] = $username['username'];
            header('location:../view/index.php');
        }

        elseif ($countadmin > 0) {
            $_SESSION['username'] = $admin['username'];
        	header('location:../admin/products/productmanagement.php');
        }
        else {
            header('location:../view/login.php?status=failed');
        }
    } 
   
?>