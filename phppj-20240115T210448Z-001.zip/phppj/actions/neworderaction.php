<?php
	session_start();
	if (empty($_SESSION["username"])) {
		header("location:../view/checkout.php?user=none");
	}
	if (isset($_SESSION["cart_item"]) && isset($_SESSION["username"])) {
		$con = mysqli_connect("localhost", "root", "", "oceangate");

		$sql1 = "SELECT customerid FROM customer WHERE username= '".$_SESSION["username"]. "'"; 
		$getUser = $con->query($sql1);
		$user = $getUser->fetch_assoc();

		$sql2 = "INSERT INTO orders(customerid, total, status) VALUES ('".$user['customerid']."','".$_GET["total"]."','PENDING')";
		$con->query($sql2);

		$last_id = $con->insert_id;
		foreach ($_SESSION["cart_item"] as $item) {
			$sql3= "INSERT INTO orderdetails VALUES('".$last_id."','".$item['price']."','".$item['productid']."','".$item['quantity']."','".$item['price']*$item['quantity']."')"; 
			$con->query($sql3);   		 
		}

		unset($_SESSION["cart_item"]);
		header("location:../view/checkout.php?bill=done");
	}
?>