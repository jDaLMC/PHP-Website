<?php 
session_start();
$item_id = $_GET['id'];
foreach ($_SESSION["cart_item"] as $select => $val) {
    if($val["productid"] == $item_id)
    {
        unset($_SESSION["cart_item"][$select]);
    }
    if (empty($_SESSION["cart_item"])) {
    	unset($_SESSION["cart_item"]);
    }
    header("location:../view/checkout.php");
}

?>