<?php
	if(isset($_POST['id'])) {
		$ROOT = $_SERVER['DOCUMENT_ROOT']."/phppj/img/userprofile/";
   		$target_dir = $ROOT . $_FILES["fileToUpload"]["name"];
    	move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_dir);

		$name = $_POST['username']; 
		$pn = $_POST['mobile'];
		$email = $_POST['email'];
		$address = $_POST['address'];
		$pass = $_POST['password'];
		$id = $_POST['id'];
		$img = "img/userprofile/".$_FILES["fileToUpload"]["name"];

		$con = mysqli_connect("localhost", "root","", "oceangate"); 

		$sqlcheck = "SELECT * FROM customer WHERE customerid='".$id."'";
		$checkpass= $con->query($sqlcheck);
		$check = $checkpass->fetch_assoc();

		if ($pass == $check['password']) {
			$sqlupdate = "UPDATE customer SET username='".$name."',phone='".$pn."',email='".$email."',address='".$address."',password='".$pass."',profilepic='".$img."' WHERE customerid='".$id."'";

			$con->query($sqlupdate);

			header("location:../view/userprofile.php");
		}
		else{
			header("location:../view/updateuser.php?pass=wrong&id=".$id);
		}
			
	}

?>