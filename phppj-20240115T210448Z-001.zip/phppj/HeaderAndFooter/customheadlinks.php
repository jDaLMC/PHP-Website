<head>
            <meta charset="utf-8">
            <title>Products - OceanGate Limited</title>
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <meta name="description" content="">
            <meta name="author" content="">
            <!--JSON-->
             <script type="text/javascript" src="products.js"></script> 

            <!-- styles -->
           <!-- <link href="https://netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="https://netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
<script src="https://code.jquery.com/jquery-1.11.1.min.js"></script>-->
			<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
            <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
			<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
            <link href="../css/bootstrap.css" rel="stylesheet">
            <link href="../css/bootstrap-responsive.css" rel="stylesheet">
            <link rel="stylesheet" href="../bootstrap-4.3.1-dist/css/bootstrap.min.css" origin="https">
            <link rel="stylesheet" href="../bootstrap-4.3.1-dist/css/bootstrap.min.css.map" origin="https">
            <link rel="stylesheet" href="../bootstrap-4.3.1-dist/css/bootstrap-grid.min.css" origin="https">
            <link rel="stylesheet" href="../bootstrap-4.3.1-dist/css/bootstrap-grid.min.css.map" origin="https">
            <link rel="stylesheet" href="../bootstrap-4.3.1-dist/css/bootstrap-reboot.min.css" origin="https">
            <link rel="stylesheet" href="../bootstrap-4.3.1-dist/css/bootstrap-reboot.min.css.map" origin="https">
			<script src="../bootstrap-4.3.1-dist/js/bootstrap.bundle.min.js" origin="https" ></script>
			<script src="../bootstrap-4.3.1-dist/js/bootstrap.bundle.min.js.map" origin="https"></script>
			<script src="../bootstrap-4.3.1-dist/js/bootstrap.min.js" origin="https"></script>
			<script src="../bootstrap-4.3.1-dist/js/bootstrap.min.js.map" origin="https"></script>
          
            <link href="../css/prettyPhoto.css" rel="stylesheet">
            <link href="../font/stylesheet.css" rel="stylesheet">
            <link href="../css/animate.css" rel="stylesheet">
            <link href="../css/flexslider.css" rel="stylesheet">
            <link rel="stylesheet" media="screen" href="../css/sequencejs.css">
            <link href="../css/style.css" rel="stylesheet">
            <link href="../color/default.css" rel="stylesheet">

          
        <title>
            Products - OceanGate
        </title>
    </head>
    <?php
		$con = mysqli_connect("localhost", "root","", "oceangate");
	?>
