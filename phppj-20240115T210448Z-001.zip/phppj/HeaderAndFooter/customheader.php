<?php
		session_start();
?>
<header>
                <!-- start top -->
                <div id="topnav" class="navbar navbar-fixed-top default" style="background-color:#2a2a2a">
                    <div class="navbar-inner">
                    <div class="container">
                        <div class="logo">
                        <a class="brand" href="index.php" style="padding:1px;"><img style="height:50px;" src="../img/additionalphotos/unnamed.png" alt=""></a>
                        </div>
                        <div class="navigation">
                        <nav>
                            <ul class="nav pull-right">
                            
                            <li><a href="index.php">Home</a></li>
                            <li class="dropdown-submenu current">
                                <a href="products.php">
                                    Products
                                </a>
                                <ul class="dropdown-menu">
                                    <li><a tabindex="-1" href="sortproducts.php?sort=48mmDC">4mm & 8mm Data Cartridges</a></li>
                                    <li><a tabindex="-1" href="sortproducts.php?sort=AIT">AIT - Advanced Intelligence Tapes</a></li>
                                    <li><a tabindex="-1" href="sortproducts.php?sort=BRN">Burners</a></li>
                                    <li><a tabindex="-1" href="sortproducts.php?sort=DStac">Disc Stakka</a></li>
                                    <li class="dropdown-submenu"><a tabindex="-1" href="products.php">Optical Disc</a>
                                        <ul class="dropdown-menu">
                                            <li><a href="sortproducts.php?sort=CRM">CD-RW Media</a></li>
                                            <li><a href="sortproducts.php?sort=DVDM">DVD Media</a></li>
                                            <li><a href="sortproducts.php?sort=FM">Forcefield Media</a></li>
                                        </ul> 
                                    </li>
                                </ul>
                            </li>
                            <li><a href="contactus.php">Contact Us</a></li>
                            <?php
						
			    			
			                	if (isset($_SESSION['username'])) {
			                		echo "<li><a href='userprofile.php'>".$_SESSION['username']." </a> </li>";
			                		echo "<li><a href='../actions/logout.php'>Log Out </a> </li>";
			                	}
			                	else {
			                		echo "<li><a href='login.php'>Log In</a></li>";
			                	}
			                 ?>

                            <li><a href="checkout.php"> <span class="fa fa-shopping-cart"></span> Cart </a></li>
                            <li>
						      <form action="search.php" method="post" class="search-form">
				                <div class="form-group has-feedback">
				            		<label for="search" class="sr-only">Search</label>
				            		<input type="text" class="form-control" name="search" id="search" placeholder="Search...">
				              		<span class="fa fa-search form-control-feedback"></span>
				            	</div>
				              </form>
							</li>
                            </ul>
                        </nav>
                        </div>
                        <!--/.nav-collapse -->
                    </div>
                    </div>
                </div>
                <!-- end top -->
                </header>
                <?php
					$con = mysqli_connect("localhost", "root","", "oceangate");
                 ?>
