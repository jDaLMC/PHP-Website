     <!-- Javascript Library Files -->
  <script src="../js/jquery.min.js"></script>
  <script src="../js/jquery.easing.js"></script>
  <script src="../js/bootstrap.js"></script>
  <script src="../js/jquery.lettering.js"></script>
  <script src="../js/parallax/jquery.parallax-1.1.3.js"></script>
  <script src="../js/nagging-menu.js"></script>
  <script src="../js/sequence.jquery-min.js"></script>
  <script src="../js/sequencejs-options.sliding-horizontal-parallax.js"></script>
  <script src="../js/portfolio/jquery.quicksand.js"></script>
  <script src="../js/portfolio/setting.js"></script>
  <script src="../js/jquery.scrollTo.js"></script>
  <script src="../js/jquery.nav.js"></script>
  <script src="../js/modernizr.custom.js"></script>
  <script src="../js/prettyPhoto/jquery.prettyPhoto.js"></script>
  <script src="../js/prettyPhoto/setting.js"></script>
  <script src="../js/jquery.flexslider.js"></script>
<!-- <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>-->

  <!-- Contact Form JavaScript File -->
  <script src="../contactform/contactform.js"></script>

  <!-- Template Custom Javascript File -->
  <script src="../js/custom.js"></script>