                <!-- footer-->
            <footer class="fixedfooter">
                    <div class="verybottom">
                      <div class="container">
                        <div class="row">
                          <div class="span12">
                            <div class="aligncenter">
                              <div class="logo">
                                <a class="brand" href="index.php">
                                    <img src="img/additionalphotos/unnamed.png" alt="">
                                </a>
                              </div>
                              <p>Please feel free to reach out to us on social media. We would be honored to assist you</p>
                              <div class="social-links">
                                <ul class="social-links">
                                  <li><a href="#" title="Twitter"><i class="icon-circled icon-64 icon-twitter"></i></a></li>
                                  <li><a href="#" title="Facebook"><i class="icon-circled icon-64 icon-facebook"></i></a></li>
                                  <li><a href="#" title="Google plus"><i class="icon-circled icon-64 icon-google-plus"></i></a></li>
                                  <li><a href="#" title="Linkedin"><i class="icon-circled icon-64 icon-linkedin"></i></a></li>
                                  <li><a href="#" title="Pinterest"><i class="icon-circled icon-64 icon-pinterest"></i></a></li>
                                </ul>
                              </div>
                              <p>
                                &copy; OceanGate - All right reserved
                              </p>
                              <div class="credits">
                                Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                </footer>
                <!-- end footer-->
                </div>