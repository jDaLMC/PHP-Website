<!DOCTYPE html> 
<html><title>Order Management</title>
	<?php
		require ("../adminlinks.php");
	 ?>
	<body>
		<?php
			require ("../adminheader.php");
		 ?>
		 <h1>Order Detail</h1>
		<table class="table">
			<tr> 
				<th>Order Id</th>
				<th>Product Image</th>
				<th>Product Name</th>
				<th>Unit Price</th>
				<th>Quantity</th>
				<th>Subtotal</th>
			</tr>
		<?php
			$sql = "SELECT o.orderid, o.price, o.quantity, p.name, p.imgurl FROM orderdetails o JOIN product p ON p.productid = o.productid WHERE ".$_GET['id']." = o.orderid ";
			
			$result = $con->query($sql);
			while ($row = $result->fetch_assoc()) {
				echo "<tr>";
				echo "	<td>".$_GET['id']."</td>";
				echo "	<td style='width: 350px;'><img src='../../".$row['imgurl']."' class='img-thumbnail img-responsive img-new' style='height: 150px;'></td>";
				echo "	<td>".$row['name']."</td>";
				echo "	<td>$".$row['price']."</td>";
				echo "	<td>".$row['quantity']."</td>";
				echo "	<td>".$row['quantity']*$row['price']."</td>";
				echo "</tr>";
			}
		?>
		</table>
	</body>
</html>