<?php
	require ("../adminlinks.php");
	require ("../adminheader.php");
?>
<form method="POST" action="editorderaction.php">
	<input type="hidden" name="id" value="<?php echo $_GET['id'] ?>">				
	<table class="table"> 
		<tr> 
			<td> 
				Customer ID:
			</td>
			<td>
				<?php echo $_GET['customerid'] ?>
			</td>
		</tr>
		<tr> 
			<td> 
				Total:
			</td>
			<td>
				<?php echo $_GET['total'] ?>
			</td>
		</tr>
		<tr> 
			<td> 
				Date Created:
			</td>
			<td>
				<?php echo $_GET['orderdate'] ?>
			</td>
		</tr>
		<tr> 
			<td> 
				Status:
			</td>
			<td>
				<select name="status">
				  <option value="COMPLETED" 
				  <?php if ($_GET['status'] == "COMPLETED") {
					  		echo "selected='true'";
					  	}
				  ?>
				  >COMPLETED</option>
				  <option value="PENDING" <?php if ($_GET['status'] == "PENDING") {
					  		echo "selected='true'";
					  	}
				  ?>>PENDING</option>
				</select>
			</td>
		</tr>
		<tr> 
			<td></td>
			<td> 
				<input type="submit" value="Submit">
			</td>
		</tr>
	</table>
</form>

