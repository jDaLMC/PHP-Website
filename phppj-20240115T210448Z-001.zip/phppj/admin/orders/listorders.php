<!DOCTYPE html> 
<html><title>Order Management</title>
	<?php
		require ("../adminlinks.php");
	 ?>
	<body>
		<?php
			require ("../adminheader.php");
		 ?>
		 <h1>Orders</h1>
		 
		<table class=" table table-hover table-responsive table-striped">
			<tr> 
				<th>Id</th>
				<th>Customer Name</th>
				<th>Total Price</th>
				<th>Date Created</th>
				<th>Status</th>
				<th>Action</th>
			</tr>
		<?php
			$sql = "SELECT * FROM orders o JOIN customer c ON c.customerid = o.customerid";
			$result = $con->query($sql);
			while ($row = $result->fetch_assoc()) {
				echo "<tr>";
				echo "	<td>".$row['orderid']."</td>";
				echo "	<td>".$row['username']."</td>";
				echo "	<td>".$row['total']."</td>";
				echo "	<td>".$row['orderdate']."</td>";
				echo "	<td>".$row['status']."</td>";
				echo "	<td><a href='editorder.php?id=".$row['orderid']."&customerid=".$row['customerid']."&total=".$row['total']."&orderdate=".$row['orderdate']."&status=".$row['status']."' class='action'>Edit</a> | <a class='action' href='orderdetail.php?id=".$row['orderid']."'>View Details</a></td>";
				echo "</tr>";
			}
		?>
		</table>
	</body>
</html>