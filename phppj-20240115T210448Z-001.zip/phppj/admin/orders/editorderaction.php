<?php
	if(isset($_POST['id'])) { 
		$status = $_POST['status'];
		$id = $_POST['id'];

		$con = mysqli_connect("localhost", "root","", "oceangate"); 

		$sqlupdate = "UPDATE orders SET status='".$status."' WHERE orderid='".$id."'";

		$con->query($sqlupdate);

		header("location:listorders.php");
	}

?>