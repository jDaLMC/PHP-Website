
<?php
	if (isset($_GET['id'])) {
		$id = $_GET['id'];
		$con = mysqli_connect("localhost", "root","", "oceangate");
		$sqldelete = "DELETE FROM product WHERE productid='".$id."'";
		$con->query($sqldelete);
		header("location:productmanagement.php"); 
	}
?>
<?php
	if(isset($_POST['name'])) {
		$ROOT = $_SERVER['DOCUMENT_ROOT']."/phppj/img/additionalphotos/";
   		$target_dir = $ROOT . $_FILES["fileToUpload"]["name"];
    	move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_dir);

		$name = $_POST['name'];
		$price = $_POST['price'];
		$type = $_POST['type'];
		$description = $_POST['description'];
		$img = "img/additionalphotos/".$_FILES["fileToUpload"]["name"];
		$status = $_POST['status'];
		$id = $_POST['id'];

		$con = mysqli_connect("localhost", "root","", "oceangate");

		$sqlinsert = "INSERT INTO product(name, typeid, price, description, imgurl, status) VALUES ('".$name."','".$type."','".$price."','".$description."','".$img."','".$status."')";

		$con->query($sqlinsert);

		header("location:productmanagement.php");
	}
?>
