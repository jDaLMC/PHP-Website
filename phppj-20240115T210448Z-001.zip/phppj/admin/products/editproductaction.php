<?php
	if(isset($_POST['id'])) {
		$ROOT = $_SERVER['DOCUMENT_ROOT']."/phppj/img/additionalphotos/";
   		$target_dir = $ROOT . $_FILES["fileToUpload"]["name"];
    	move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_dir);

		$name = $_POST['name'];
		$type = $_POST['type'];
		$price = $_POST['price']; 
		$description = $_POST['description'];
		$status = $_POST['status'];
		$id = $_POST['id'];

		if (!empty($_FILES["fileToUpload"]["name"])) {
			$img = "img/additionalphotos/".$_FILES["fileToUpload"]["name"];
		}
		else {
			$img = $_POST['img'];
		}

		$con = mysqli_connect("localhost", "root","", "oceangate"); 


		$sqlupdate = "UPDATE product SET name='".$name."',price='".$price."',description='".$description."',imgurl='".$img."',status='".$status."',typeid='".$type."' WHERE productid='".$id."'";

		$con->query($sqlupdate);

		header("location:productmanagement.php");
	}

?>