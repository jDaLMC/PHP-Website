<!DOCTYPE html>
<html><title>Product Management</title>
	<?php
		require ("../adminlinks.php");
	 ?>
	<body>
		<?php
			require ("../adminheader.php");
		 ?>
		 <h1>Products</h1>
		 <form action="filter.php" method="post" class="search-form">
            <div class="form-group has-feedback">
        		<label for="search" class="sr-only">Search</label>
        		<input type="text" class="form-control" name="search" id="search" placeholder="Search...">
          		<span class="fa fa-search form-control-feedback"></span>
        	</div>
         </form>
		 <a href="addproduct.php" class="btn btn-info">Add New Products</a>
		<table class="table table-hover table-responsive table-striped">
			<tr> 
				<th>Id</th>
				<th>Name</th>
				<th>Type</th>
				<th>Price</th>
				<th>Description</th>
				<th>Photo</th>
				<th>Status</th>
				<th>Action</th>
			</tr>
		<?php

		
			$sql = "SELECT * FROM product";
			$result = $con->query($sql);
			while ($row = $result->fetch_assoc()) {
				echo "<tr>";
				echo "	<td>".$row['productid']."</td>";
				echo "	<td>".$row['name']."</td>";
				echo "	<td>".$row['typeid']."</td>";
				echo "	<td>$".$row['price']."</td>";
				echo "	<td>".$row['description']."</td>";
				echo "	<td style='width: 350px;'><img src='../../".$row['imgurl']."' class='img-thumbnail img-responsive img-new' style='height: 150px;'></td>";
				echo "	<td style='width: 110px;'>".$row['status']."</td>";
				echo "	<td style='width: 110px;'><a href='editproduct.php?id=".$row['productid']."&name=".$row['name']."&price=".$row['price']."&description=".$row['description']."&img=".$row['imgurl']."&status=".$row['status']."&type=".$row['typeid']."' class='action'>Edit</a> |";

				$check = "SELECT * FROM orderdetails WHERE productid = '".$row['productid']."'";
				$exe = $con->query($check);
				$countexe = $exe->num_rows;
				if ($countexe > 0) {
					echo "</td></tr>";
				}
				else{
					echo "<a href='deleteaddproduct.php?id=".$row['productid']."' class='action'> Delete</a>";
					echo "</td></tr>";
				}
			}
		?>
		</table>
	</body>
</html>