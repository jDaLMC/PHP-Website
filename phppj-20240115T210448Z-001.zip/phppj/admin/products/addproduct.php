<?php
	require ("../adminlinks.php");
	require ("../adminheader.php");
?>
<form method="POST" action="deleteaddproduct.php" enctype="multipart/form-data">			
	<input type="hidden" name="id">				
	<table class="table"> 
		<tr> 
			<td> 
				Name: 
			</td>
			<td>
				<input type="text" name="name">
			</td>
			<td> 
				TYPES: <br>
				4mm & 8mm Data Cartridges : 48mmDC <br>
			</td>
		</tr>
		<tr> 
			<td> 
				Type:
			</td>
			<td>
				<input type="text" name="type">
			</td>
			<td>
				AIT - Advanced Intelligence Tapes: AIT <br>
			</td>
		</tr>
		<tr> 
			<td> 
				Price:
			</td>
			<td>
				<input type="text" name="price">
			</td>
			<td> 
				Burners : BRN <br>
			</td>
		</tr>
		<tr> 
			<td> 
				Description:
			</td>
			<td>
				<textarea type="text" name="description"></textarea>
			</td>
			<td> 
				Disc Stakka: DStac <br>				
			</td>
		</tr>
		<tr> 
			<td> 
				Photo:
			</td>
			<td>
				<input type="file" name="fileToUpload" id="fileToUpload">
			</td>
			<td>
				CD-RW Media: CRM <br>				
			</td>
		</tr>
		<tr> 
			<td> 
				Status:
			</td>
			<td>
				<select name="status">
				  <option value="Available">AVAILABLE</option>
				  <option value="Unavailable">UNAVAILABLE</option>
				</select>
			</td>
			<td> 
				DVD Media: DVDM <br>				
			</td>
		</tr>
		<tr> 
			<td></td>
			<td> 
				<input type="submit" value="Submit">
			</td>
			<td> 
				Forcefield Media: FM <br>
			</td>
		</tr>
	</table>
</form>

