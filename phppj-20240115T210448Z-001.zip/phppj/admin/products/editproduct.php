<?php
	require ("../adminlinks.php");
	require ("../adminheader.php");
?>
<form method="POST" action="editproductaction.php?img=<?php echo $_GET['img'] ?>" enctype="multipart/form-data">
	<input type="hidden" name="id" value="<?php echo $_GET['id'] ?>">				
	<table class="table"> 
		<tr> 
			<td> 
				Name:
			</td>
			<td>
				<input type="text" name="name" value="<?php echo $_GET['name'] ?>">
			</td>
		</tr>
		<tr> 
			<td> 
				Type:
			</td>
			<td>
				<input type="text" name="type" value="<?php echo $_GET['type'] ?>">
			</td>
		</tr>
		<tr> 
			<td> 
				Price:
			</td>
			<td>
				<input type="text" name="price" value="<?php echo $_GET['price'] ?>">
			</td>
		</tr>
		<tr> 
			<td> 
				Description: 
			</td>
			<td>
				<textarea type="text" name="description"><?php echo $_GET['description'] ?></textarea>
			</td>
		</tr>
		<tr> 
			<td> 
				Photo:
			</td>
			<td>
				<input type="hidden" name="img" value="<?php echo $_GET['img'] ?>">				

				<input class="col-md-2" type="file" name="fileToUpload" id="fileToUpload" value="<?php echo $_GET['img'] ?>">
			</td>
		</tr>
		<tr> 
			<td> 
				Status:
			</td> 
			<td>
				<select name="status">
				  <option value="Available" 
				  <?php if ($_GET['status'] == "Available") {
					  		echo "selected='true'";
					  	}
				  ?>
				  >Available</option>
				  <option value="Unavailable" <?php if ($_GET['status'] == "Unavailable") {
					  		echo "selected='true'";
					  	}
				  ?>>Unavailable</option>
				</select>
			</td>
		</tr>
		<tr> 
			<td></td>
			<td> 
				<input type="submit" value="Submit">
			</td>
		</tr>
	</table>
</form>

