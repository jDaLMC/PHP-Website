
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li><a href="../products/productmanagement.php">Products Management</a></li>
        <li><a href="../orders/listorders.php">Orders</a></li>
		
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a><u><?php session_start(); echo $_SESSION["username"]; ?></u></a></li>
      	<li><a href="../logout.php">Log out</a></li>
      	<li>				   
		</li>
      </ul>
    </div>
  </div>
</nav>