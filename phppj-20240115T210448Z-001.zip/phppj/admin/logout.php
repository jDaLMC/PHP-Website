<?php session_start(); 
 
if (isset($_SESSION['username'])){
    unset($_SESSION['username']);
    header('location:../view/index.php');
}
else {
    header('location:../view/index.php');
	
} 
?>
