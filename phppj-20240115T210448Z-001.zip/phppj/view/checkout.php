<!doctype html>
<html class="newhtml">
<head> 
	<title>Cart</title>
</head>
    <?php
    	require ("../HeaderAndFooter/customheadlinks.php");
     ?>
    <body class="newbody">
   <div class="productspagecontainer">
            <?php
            	require ("../HeaderAndFooter/customheader.php");
             ?>

                <div class="container">
	<table id="cart" class="table table-hover table-condensed">
    				<thead>
						<tr>
							<th style="width:50%">Product</th>
							<th style="width:10%">Price</th>
							<th style="width:8%">Quantity</th>
							<th style="width:22%" class="text-center">Subtotal</th>
							<th style="width:10%"></th>
						</tr>
					</thead>
					<tbody id="bill">
					
						<?php
							if(isset($_SESSION["cart_item"])){
								$total=0;
							    foreach ($_SESSION["cart_item"] as $item){
									$subtotal = $item['price']*$item['quantity'];
		                			$total += $subtotal;
		        					echo "<tr><td data-th='Product'><div class='row'>";
		        					echo "<div class='col -sm-2 hidden-xs'><img src='../".$item['image']."'class='img-responsive'/></div>";
		        					echo "<div class='col-sm-10'><h4 class='nomargin'>".$item['name']."</h4>";
		        					echo "<p>".$item['description']."</p></div></div></td>";
		        					echo "<td data-th='Price'>".$item['price']."</td><td data-th='Quantity'>";
		        					echo "<input type='number' min='1' max='10' name='quantity' class='form-control text-center' value='".$item['quantity']."'></td>";
		        					echo "<td data-th='Price' class='text-center'>".$item['price']*$item['quantity']."</td><td class='actions' data-th=''>";
		        					echo "<a href='../actions/deletefromcart.php?actionas=delete&id=".$item['productid']."' style='color: white'><button class='btn btn-danger btn-sm'><i class='fa fa-trash-o'>Remove</i></button></a></td></tr></tbody>";
		                		}
		                		echo "<tfoot><tr><td><a href='products.php' class='btn btn-warning'><i class='fa fa-angle-left'></i> Continue Shopping</a></td><td colspan='2' class='hidden-xs'></td>";
		        					echo "<td class='hidden-xs text-center'><strong>Total ".$total."</strong></td>";
		        					echo "<td><a href='../actions/neworderaction.php?total=".$total."' class='btn btn-success btn-block'>Checkout <i class='fa fa-angle-right'></i></a></td></tr></form>";
		                	}
		                		if (!isset($_SESSION["cart_item"]) && !isset($_GET["bill"])) {
		                			echo "<br><br><h1>Your cart is empty</h1><br><br><br>";
		                		}

		                	if (isset($_GET['user'])) {
		                		echo "<script>alert('Please log in to make your purchase')</script>";
		                	}
		                	if (isset($_GET['bill'])) {
		                		echo "<br><br><h1>your purchase was successful<h1><br><br><br>";
		                	}
		                			
			                		?>

	                		
					</tfoot>
				</table>
</div>

               <?php
    	require ("../HeaderAndFooter/customfooter.php");
    	require ("../HeaderAndFooter/customfootlinks.php");
     ?>

</body>
</html>