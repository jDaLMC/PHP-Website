<!doctype html>
<html class="newhtml">
    <?php
    if (isset($_POST['search'])) {
    	$search = $_POST['search'];
    }
	
	if (isset($_GET['search'])) {
    	$search = $_GET['search'];
    }

    	require ("../HeaderAndFooter/customheadlinks.php");

    	if (isset($_GET['page']) && $_GET['page']!="") {
		    $page = $_GET['page'];
		    } 
		else {
		        $page = 1;
		     }
		$limit = 6;

		$from = ($page-1) * $limit;

		$count = $con->query(
		"SELECT COUNT(*) AS total FROM `product` WHERE name LIKE '%".$search."%'"
		);
		$total = mysqli_fetch_array($count);
		$total = $total['total'];
		$total_pages = ceil($total / $limit);
     ?>
    <body class="newbody">
   <div class="productspagecontainer">
            <?php
            	require ("../HeaderAndFooter/customheader.php");
             ?>
                <!--breadcrumb-->
					<nav aria-label="breadcrumb">
					  <ol class="breadcrumb">
					    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
					    <li class="breadcrumb-item">Products</li>
					  </ol>
					</nav>
                <!--end breadcrumb-->

                <!-- product page body -->
                <div class="row">
	                <div class="newaside col-md-3 col-sm-3 col-xs-3 col-lg-3">
			          <h1 class="my-2">All Products</h1>
			          <div class="list-group">
			            <a href="sortproducts.php?sort=48mmDC" class="list-group-item">4mm & 8mm Data Cartridges</a>
			            <a href="sortproducts.php?sort=AIT" class="list-group-item">AIT - Advanced Intelligence Tapes</a>
			            <a href="sortproducts.php?sort=BRN" class="list-group-item">Burners</a>
			            <a href="sortproducts.php?sort=DStac" class="list-group-item">Disc Stakka</a>
			            <a href="sortproducts.php?sort=CRM" class="list-group-item">CD-RW Media</a>
			            <a href="sortproducts.php?sort=DVDM" class="list-group-item">DVD Media</a>
			            <a href="sortproducts.php?sort=FM" class="list-group-item">Forcefield Media</a>
				</div>
				  </div>
	<!-- updating products -->
	                <div id="productsbody" class="col-md-9 col-sm-9 col-xs-9 row">
	                	<div id="productcards" class="row">
	                		<?php 
	                			if (isset($_POST['search']) || isset($_GET['search'])){
	                				$sqls = "SELECT * FROM product WHERE name LIKE '%".$search."%' LIMIT $from, $limit";
	                				$runrow = $con->query($sqls);
	                				while ($run = $runrow->fetch_assoc()) {
	                					echo "<div class='card col-md-4 col-lg-4 col-sm-4 col-xs-4'>";
			                			echo "<a href='productdetails.php?id=".$run['productid']."'><img src='../".$run['imgurl']."' class='card-img-top img-responsive' style='height:230px;' alt='...'></a>";
			                			echo "<div class='card-body'>";
			                			echo "<h5 class='card-title'>".$run['name']."</h5>";
			                			echo "<a href='productdetails.php?id=".$run['productid']."' class='btn btn-primary'>Buy ".$run['price']." </a>";
			                			echo "</div></div><br><br>";
	                				}
	                			}
	                		?>
							<!-- end updating -->
	                	</div>

	                	 <!-- button toolbar -->
					    <div id="pdivider" style="float:right"> 
					    	<ul class="pagination">
								<?php
									if ($total_pages <= 10){  	 
										for ($count = 1; $count <= $total_pages; $count++){
										if ($count == $page) {
										echo "<li class='active page-item'><a class='page-link'>$count</a></li>";
										}
										else{
									        echo "<li class='page-item'><a class='page-link' href='search.php?page=$count&search=$search'>$count</a></li>";
									                }
									        }
									}
								?>
							</ul>
					    	<div style='padding: 10px 20px 0px; border-top: dotted 1px #CCC;'>
								<strong>Page <?php echo $page." of ".$total_pages; ?></strong>
							</div>

					    </div>
					  </div>
					 </div>
	            <!-- end button toolbar -->
	            
	                </div>
	            </div>
	            <!--end product page body-->

    <?php
    	require ("../HeaderAndFooter/customfooter.php");
    	require ("../HeaderAndFooter/customfootlinks.php");
     ?>

</body>
</html>