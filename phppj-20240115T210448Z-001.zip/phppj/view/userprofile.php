<head> 
	<title>User Profile</title>
</head>
<?php
		session_start();
		$con = mysqli_connect("localhost", "root","", "oceangate");
?>
<?php 
    require ("../HeaderAndFooter/customheadlinks.php");
   

	$sql = "SELECT * FROM customer WHERE username='".$_SESSION['username']."'";
		$result = $con->query($sql);
		$row = $result->fetch_assoc(); 

?>

<header>
                <!-- start top -->
                <div id="topnav" class="navbar navbar-fixed-top default" style="background-color:#2a2a2a">
                    <div class="navbar-inner">
                    <div class="container">
                        <div class="logo">
                        <a class="brand" href="index.php" style="padding:1px;"><img style="height:50px;" src="../img/additionalphotos/unnamed.png" alt=""></a>
                        </div>
                        <div class="navigation">
                        <nav>
                            <ul class="nav pull-right">
                            <li><a href="index.php">Home</a></li>
                            <li class="dropdown-submenu">
                                <a href="products.php">
                                    Products
                                </a>
                                <ul class="dropdown-menu">
                                    <li><a tabindex="-1" href="sortproducts.php?sort=4mm and 8mm Data Cartrides">4mm & 8mm Data Cartridges</a></li>
                                    <li><a tabindex="-1" href="sortproducts.php?sort=AIT - Advanced Intelligence Tapes">AIT - Advanced Intelligence Tapes</a></li>
                                    <li><a tabindex="-1" href="sortproducts.php?sort=Burners">Burners</a></li>
                                    <li><a tabindex="-1" href="sortproducts.php?sort=Data Centre Tape & Services">Data Centre Tape & Services</a></li>
                                    <li><a tabindex="-1" href="sortproducts.php?sort=Disc Stakka">Disc Stakka</a></li>
                                    <li class="dropdown-submenu"><a tabindex="-1" href="products.php">Optical Disc</a>
                                        <ul class="dropdown-menu">
                                            <li><a href="sortproducts.php?sort=CD-RW Media">CD-RW Media</a></li>
                                            <li><a href="sortproducts.php?sort=DVD Media">DVD Media</a></li>
                                            <li><a href="sortproducts.php?sort=Forcefield Media">Forcefield Media</a></li>
                                            <li><a href="sortproducts.php?sort=LightScribe Media">LightScribe Media</a></li>
                                            <li><a href="sortproducts.php?sort=Printable Media">Printable Media</a></li>
                                        </ul> 
                                    </li>
                                </ul>
                            </li>
                            <li><a href="contactus.php">Contact Us</a></li>
                            <?php
						
			    			
			                	if (isset($_SESSION['username'])) {
			                		echo "<li class='current'><a href='userprofile.php'>".$_SESSION['username']." </a> </li>";
			                		echo "<li><a href='../actions/logout.php'>Log Out </a> </li>";
			                	}
			                	else {
			                		echo "<li><a href='login.php'>Log In</a></li>";
			                	}
			                 ?>
                            </ul>
                        </nav>
                        </div>
                        <!--/.nav-collapse -->
                    </div>
                    </div>
                </div>
                <!-- end top -->
                </header>
                <?php
					$con = mysqli_connect("localhost", "root","", "oceangate");
                 ?>

 <head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>


<hr>
<div class="container bootstrap snippet">
    <div class="row" style="height:100px;">
  		
    </div>
    </div>
    <div class="row">
  		<div class="col-sm-3"><!--left col-->
              
      <div class="text-center">
      	<?php 
      		if (!empty($row['profilepic'])) {
				echo "<img src='../".$row['profilepic']."' class='avatar img-circle img-thumbnail' alt='avatar'>";
      		}
      		else{
				echo "<img src='http://ssl.gstatic.com/accounts/ui/avatar_2x.png' class='avatar img-circle img-thumbnail' alt='avatar'>";
      		}
      	?>
      </div></hr><br>
          
        </div><!--/col-3-->
    	<div class="col-sm-9">
            <ul class="nav nav-tabs">
                <li class="active"><a data-toggle="tab" href="#home">Home</a></li>
              	<li><a data-toggle='tab' href="#pass">Change Password</a></li>
              </ul>
              
          <div class="tab-content">
            <div class="tab-pane active" id="home">
                <hr>
                  <form class="form" action="updateuser.php" method="post" id="registrationForm">
					<input type="hidden" name="id" value="<?php echo $row['customerid'] ?>">
                      <div class="form-group">
                          
                          <div class="col-xs-6">
                              <label for="first_name"><h2>Username</h2></label>
                              <h3> 
                              	<?php 
                              		echo $row['username'];
                              	?>
                              </h3>
                          </div>
                      </div>
                      <div class="form-group">
                          
                      </div>
          
                      <div class="form-group">
                          
                      </div>
          
                      <div class="form-group">
                          <div class="col-xs-6">
                             <label for="mobile"><h2>Mobile</h2></label>
                              <h3> 
                              	<?php 
                              		echo $row['phone'];
                              	?>
                              </h3>
                          </div>
                      </div>
                      <div class="form-group">
                          
                          <div class="col-xs-6">
                              <label for="email"><h2>Email</h2></label>
                              <h3> 
                              	<?php 
                              		echo $row['email'];
                              	?>
                              </h3>
                          </div>
                      </div>
                      <div class="form-group">
                          
                          <div class="col-xs-6">
                              <label for="email"><h2>Address</h2></label>
                              <h3> 
                              	<?php 
                              		echo $row['address'];
                              	?>
                              </h3>
									<input type="hidden" name="password" value="<?php echo $row['password'] ?>">
                          </div>
                      </div>
                      <div class="form-group">
                          
                      </div>
                      <div class="form-group">
                          
                      </div>
                      <div class="form-group">
                           <div class="col-xs-12">
                                <br>
                              	<button class="btn btn-lg btn-success" type="submit"><i class="glyphicon glyphicon-ok-sign"></i> Edit</button>
                            </div>
                      </div>
              	</form>
              
              <hr>
               
              </div><!--/tab-pane-->

            <div class="tab-pane" id="pass">
                <hr>
                  <form class="form" action="../actions/updatepassword.php" onsubmit="validatePassword()" method="post" id="registrationForm">
					<input type="hidden" name="id" value="<?php echo $row['customerid'] ?>">
                      <div class="form-group">
                          <div>
                              <label for="oldpass"><h2>Old Password:</h2></label>
                              <input type="password" name="oldpass"></input>
                          </div>
                      </div>
          
                      <div class="form-group">
                          <div>
                             <label for="newpass"><h2>New Password:</h2></label>
                              <input type="password" name="newpass" id="newpass"></input>
                          </div>
                      </div>
                      <div>
                          <div>
                              <label for="repass"><h2>Confirm Password:</h2></label>
                              <input type="password" name="repass" id="repass"></input>
                          </div>
                      </div>
                      <div class="form-group">
                           <div class="col-xs-12">
                                <br>
                              	<button class="btn btn-lg btn-success" type="submit"><i class="glyphicon glyphicon-ok-sign"></i> Confirm</button>
                            </div>
                      </div>

              	</form>
              	<script> 

                        var password = document.getElementById("newpass");
                        var confirm_password = document.getElementById("repass");

                        function validatePassword(){
                        if(password.value != confirm_password.value) {
                        confirm_password.setCustomValidity("Passwords Don't Match");
                        } else {
                        confirm_password.setCustomValidity('');
                        }
                        }

                        password.onchange = validatePassword;
                        confirm_password.onkeyup = validatePassword;          
                        </script>
              
              <hr>
              </div><!--/tab-pane-->
          </div><!--/tab-content-->

        </div><!--/col-9-->
    </div><!--/row-->

    <?php
    	require ("../HeaderAndFooter/customfooter.php");
    	require ("../HeaderAndFooter/customfootlinks.php");
     ?>
     <?php 
     	if (isset($_GET['oldpass'])) {
     		echo "<script>
     			alert('Incorrect Old Password');
     		</script>";
     	}
     	if (isset($_GET['update'])) {
     		echo "<script>
     			alert('Password Updated Successfully');
     		</script>";
     	}
     ?>
