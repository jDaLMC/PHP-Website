<?php 
  require ("../HeaderAndFooter/customheadlinks.php");

?>
<body class="newbody">
  <div class="productspagecontainer">
    <header>
      <!-- start top -->
      <div id="topnav" class="navbar navbar-fixed-top default" style="background-color:#2a2a2a">
        <div class="navbar-inner">
          <div class="container">
            <div class="logo">
              <a class="brand" href="index.php" style="padding:1px;"><img style="height:50px;"
                  src="../img/additionalphotos/unnamed.png" alt=""></a>
            </div>
            <div class="navigation">
              <nav>
                <ul class="nav float-right">
                  <li><a href="index.php">Home</a></li>
                  <li class=" current">
                    <a href="register.php">
                      Sign Up
                    </a>
                  </li>
                  <li>
                    <a href="login.php">
                      Login
                    </a>
                    </li>
                  <li><a href="contactus.php">Contact Us</a></li>
                </ul>
              </nav>
            </div>
            <!--/.nav-collapse -->
          </div>
        </div>
      </div>
      <!-- end top -->
    </header>


    <div class="container">
        <div class="row">
                <div class="col-sm-6 offset-sm-3">
                        <div class="card">
                            <div class="card-header">
                             Register
                            </div>
                            <div class="card-body">
                              <form method="POST" action="register.php" onsubmit="validatePassword()">
            
            
                                  <div class="form-group">
                                      <label for="email" class="col-sm-5 control-label">Email:</label>
                                        
                                      <div class="col-sm-7">
                                        <input type="text" name="email" value="" required="required" class="form-control">
                                      </div>
                                    </div>
                              
                                    <div class="form-group">
                                      <label for="username" class="col-sm-5 control-label">Username:</label>
                                      <div class="col-sm-7">
                                        <input type="text" name="username" required="required" class="form-control">
                                      </div>
                                    </div>

                                    <div class="form-group">
                                            <label for="password" class="col-sm-5 control-label">Password:</label>
                                            <div class="col-sm-7">
                                              <input id="password" type="password" name="password" required="required" class="form-control">
                                            </div>
                                          </div>
                                    
                                          <div class="form-group">
                                            <label for="repassword" class="col-sm-5 control-label"> Confirm Password:</label>
                                            <div class="col-sm-7">
                                              <input id="confirm_password" type="password" name="repassword" required="required" class="form-control">
                                            </div>
                                          </div>
                                            
                                         
                                     <div class="form-group">
                                      <label class="col-sm-5 control-label">Address:</label>
                                        
                                      <div class="col-sm-7">
                                        <input type="text" name="address" required="required" class="form-control">
                                      </div>
                                    </div>

                                    <div class="form-group">
                                      <label for="phone" class="col-sm-5 control-label">Phone Number:</label>
                                        
                                      <div class="col-sm-7">
                                        <input type="tel" title="Please enter a valid phone number" pattern="[0-9]{10}" name="digits" required="required" class="form-control">
                                      </div>
                                    </div>

                                    <div class="form-group">
                                        <div class="offset-sm-5 col-sm-7">
                                          <input type="submit" id="submit" name="submit" value="Register" class="btn btn-primary">                             
                                        </div>
                                      </div>
                                       <script> 

                                      var password = document.getElementById("password");
                                      var confirm_password = document.getElementById("confirm_password");

                                      function validatePassword(){
                                      if(password.value != confirm_password.value) {
                                      confirm_password.setCustomValidity("Passwords Don't Match");
                                      } else {
                                      confirm_password.setCustomValidity('');
                                      }
                                      }

                                      password.onchange = validatePassword;
                                      confirm_password.onkeyup = validatePassword;          
                                      </script>
                              </form>
                             
                             
                            </div>
                          </div>
                    </div>
        </div>
    </div>

</body>


 <?php
    
  
    if(isset($_POST['username'])){
        $email = $_POST['email']; 
        $username = $_POST['username']; 
        $password = $_POST['password'];
        $pn = $_POST['digits'];
        $address = $_POST['address'];        
       
        $conn = mysqli_connect("localhost","root","","oceangate");

        $sql = "INSERT INTO customer (email ,username, password, phone, address) VALUES ('".$email."','".$username."','".$password."','".$pn."','".$address."')";

        $conn->query($sql);
        echo "<script type='text/javascript'>alert('Registered successfully. Please Log in again');</script>";
        }
        
        
?>