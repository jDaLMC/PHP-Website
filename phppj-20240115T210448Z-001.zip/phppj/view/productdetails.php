<!doctype html>
<html class="newhtml" onload="getUrlVars()">
    <?php
    	require ("../HeaderAndFooter/customheadlinks.php");
     ?>
    <body class="newbody">
   <div class="productspagecontainer">
             <?php
            	require ("../HeaderAndFooter/customheader.php");
             ?>

                <!--breadcrumb-->
					<nav aria-label="breadcrumb">
					  <ol class="breadcrumb">
					    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
					    <li class="breadcrumb-item"><a href="products.php">Products</a></li>
					    <li class="breadcrumb-item">Product's Details</li>
					  </ol>
					</nav>
                <!--end breadcrumb-->

                <!-- product page body -->
                <div class="row">
	                <div class="newaside col-md-3">
			          <h1 class="my-2">All Products</h1>
			          <div class="list-group">
			            <a href="sortproducts.php?sort=48mmDC" class="list-group-item">4mm & 8mm Data Cartridges</a>
			            <a href="sortproducts.php?sort=AIT - Advanced Intelligence Tapes" class="list-group-item">AIT - Advanced Intelligence Tapes</a>
			            <a href="sortproducts.php?sort=BRN" class="list-group-item">Burners</a>
			            <a href="sortproducts.php?sort=DStac" class="list-group-item">Disc Stakka</a>
			            <a href="sortproducts.php?sort=CRM" class="list-group-item">CD-RW Media</a>
			            <a href="sortproducts.php?sort=DVDM" class="list-group-item">DVD Media</a>
			            <a href="sortproducts.php?sort=Fm" class="list-group-item">Forcefield Media</a>
			        </div>
				   </div>
				 <!-- end menu-->
				 
				 <!--product's details-->
	                <div id="productsbody" class="col-md-9">
	                	<div class="card">
	                	<div class="row" id="details">	
	                	<?php 
	                			if (isset($_GET['id'])) {
	                				$sql = "SELECT * FROM product WHERE productid = '".$_GET['id']."'";
	                				$result = $con->query($sql);
	                				while ($row = $result->fetch_assoc()) {
	                					echo "<div class='col-md-5'><article class='gallery-wrap'>";
	                					echo "<div class='img-big-wrap'><div>";
	                					echo "<img src='../".$row['imgurl']."'></div></div>";
	                					echo "<form action='../actions/newproduct.php' method='post'>";
	                					echo "<input type='hidden' name='id' value='".$row['productid']."'>";
	                					echo "</article></div><div class='col-md-7'><article class='card-body'>";
	                					echo "<h3 class='title mb-3'>".$row['name']."</h3>";
	                					echo "<p class='price-detail-wrap'><span class='price h3 text-warning'>";
	                					echo "<span class='currency'>$".$row['price']."</span></span></p>";
	                					echo "<dl class='item-property'><dt>Description</dt>";
	                					echo "<dd><p>".$row['description']."</p></dd></dl>";
	                					echo "<hr><dl class='param param-inline'><dt>Quantity:</dt><dd>";
	                					echo "<input type='number' value='1' min='1' max='10' name='quantity' class='form-control form-control-sm' style='width:70px;'>";
	                					echo "</dd></dl><hr>";
	                					echo "<input type='submit' value='Add To Cart' class='btn btn-lg btn-primary text-uppercase'></article></form></div>";
	                				}
	                			}
	                		?>				
	                	</div>
	                </div>
	                <!--user comments-->
	                <h1> 
	                	reviews
	                </h1>
	        <div id="newreview"> 

	        </div>
	        <!--post review-->
	        <div class="card">
	    <div class="card-body">
	        <div class="row">
        	    <div class="col-md-2">
        	        <img src="https://image.ibb.co/jw55Ex/def_face.jpg" class="img img-rounded img-fluid"/>
        	    </div>
        	    <div class="col-md-10">
        	        <p>
        	            <a class="float-left" href="https://maniruzzaman-akash.blogspot.com/p/contact.php"> 
        	            	<input type="text" id="username" required placeholder="Your Name">
        	            </a>
        	            <span class="float-right"><i class="text-warning fa fa-star"></i></span>
                        <span class="float-right"><i class="text-warning fa fa-star"></i></span>
        	            <span class="float-right"><i class="text-warning fa fa-star"></i></span>
        	            <span class="float-right"><i class="text-warning fa fa-star"></i></span>

        	       </p>
        	       <div class="clearfix"></div>
        	        <textarea id="opinion"></textarea>
        	        <p>
        	            <i class="fa fa-heart"><button class="float-right btn text-white btn-danger" onclick="reviewsubmit()">Submit</button></i>	
        	       </p>
        	    </div>
	        </div></div></div>
	        <script> 
	        	function reviewsubmit(){
	        		var review="";
	        		var comment=document.getElementById("opinion").value;
	        		var name=document.getElementById("username").value;
	        		review +="<div class='card'>";
			    	review +="<div class='card-body'>";
			        review +="<div class='row'>";
		        	review +="<div class='col-md-2'>";
		        	review +="<img src='https://image.ibb.co/jw55Ex/def_face.jpg' class='img img-rounded img-fluid'/>";
		        	review +="<p class='text-secondary text-center'>Just now</p></div>"; 
		        	review +="<div class='col-md-10'>";
		        	review +="<p>";
		        	review +="<a class='float-left' href='https://maniruzzaman-akash.blogspot.com/p/contact.php'>";
		        	review +="<strong>"+name+"</strong></a>"
		        	review +="<span class='float-right'><i class='text-warning fa fa-star'></i></span>";
	                review +="<span class='float-right'><i class='text-warning fa fa-star'></i></span>";
	        	    review +="<span class='float-right'><i class='text-warning fa fa-star'></i></span>";
	        	    review +="<span class='float-right'><i class='text-warning fa fa-star'></i></span></p>";
	        	    review +="<div class='clearfix'></div>";
		        	review +="<p>"+comment+"</p>";
		        	review +="<p>";
		        	review +="<a class='float-right btn btn-outline-primary ml-2'><i class='fa fa-reply'></i> Reply</a>";
		        	review +="<a class='float-right btn text-white btn-danger'> <i class='fa fa-heart'></i> Like</a>";
		        	review +="</p></div></div></div></div>";
		        	document.getElementById("newreview").innerHTML=review;
	        	}
	        	
	        </script>
	        	<!--end post review-->

	            <!--end user comments--> 
	                </div></div></div><!-- end product's details-->
	            <!--end product page body-->
   <?php
    	require ("../HeaderAndFooter/customfooter.php");
    	require ("../HeaderAndFooter/customfootlinks.php");
     ?>

</body>
</html>