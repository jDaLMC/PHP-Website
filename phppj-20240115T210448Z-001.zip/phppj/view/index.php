<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <title>OceanGate Limited</title>

  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="">
  <!-- styles -->
  <link href="../css/bootstrap.css" rel="stylesheet">
  <link href="../css/bootstrap-responsive.css" rel="stylesheet"> 

  <link href="../css/prettyPhoto.css" rel="stylesheet">
  <link href="../font/stylesheet.css" rel="stylesheet">
  <link href="../css/animate.css" rel="stylesheet">
  <link href="../css/flexslider.css" rel="stylesheet">
  <link rel="stylesheet" media="screen" href="../css/sequencejs.css">
  <link href="../css/style.css" rel="stylesheet">
  <link href="../color/default.css" rel="stylesheet">


</head>

<body>
  <header>

    <!-- start top -->
    <div id="topnav" class="navbar navbar-fixed-top default">
      <div class="navbar-inner">
        <div class="container">
          <div class="logo">
            <a class="brand" href="index.php" style="padding:1px;"><img style="height:50px;" src="../img/additionalphotos/unnamed.png" alt=""></a>
          </div>
          <div class="navigation">
            <nav>
              <ul class="nav pull-right">
                <li class="current"><a href="index.php">Home</a></li>
                <li><a href="#dailydeals">Daily Deals</a></li>
                <li><a href="#about">About Us</a></li>
                <li><a href="#where">Where to Buy</a></li>
                <li><a href="#support">Support</a></li>
                <li class="dropdown-submenu">
                	<a href="products.php">
                		Products
                	</a>
                	<ul class="dropdown-menu">
                		<li><a tabindex="-1" href="sortproducts.php?sort=48mmDC">4mm & 8mm Data Cartridges</a></li>
                		<li><a tabindex="-1" href="sortproducts.php?sort=AIT">AIT - Advanced Intelligence Tapes</a></li>
                		<li><a tabindex="-1" href="sortproducts.php?sort=BRN">Burners</a></li>
                		<li><a tabindex="-1" href="sortproducts.php?sort=DStac">Disc Stakka</a></li>
                		<li class="dropdown-submenu"><a tabindex="-1" href="#">Optical Disc</a>
            				<ul class="dropdown-menu">
                				<li><a href="sortproducts.php?sort=CRM">CD-RW Media</a></li>
                				<li><a href="sortproducts.php?sort=DVDM">DVD Media</a></li>
                				<li><a href="sortproducts.php?sort=FM">Forcefield Media</a></li>
            				</ul> 
                		</li>
                	</ul>
                </li>
                <li><a href="contactus.php">Contact Us</a></li>
                
                <?php
                	session_start();
	            	if (isset($_SESSION['username'])) {
	            		echo "<li><a href='userprofile.php'>".$_SESSION['username']." </a> </li>";
	            		echo "<li><a href='../actions/logout.php'>Log Out </a> </li>";
	            	}
	            	else {
	            		echo "<li><a href='login.php'>Log In</a></li>";
	            	}
	             ?>
	            <li><a href="checkout.php">Cart</a></li>
                 
             
              </ul>
            </nav>
          </div>
          <!--/.nav-collapse -->
        </div>
      </div>
    </div>
    <!-- end top -->
  </header>

  <!-- section featured -->
  <section id="featured">

    <!-- sequence slider -->
    <div id="sequence-theme">
      <img class="prev" src="../img/bt-prev.png" alt="Previous">
      <img class="next" src="../img/bt-next.png" alt="Next">
      <div class="container">
        <div class="row">
          <div class="span12">
            <div id="sequence">
              <ul>
                <li class="animate-in">
                  <div class="info letter-container">
                    <h2 class="fade">we are oceangate</h2>
                  </div>
                  <h4 class="subtitle">You can trust us with data storage services</h4>
                  <div class="bottomup">
                    <img src="../img/additionalphotos/home.png" alt="">
                  </div>
                </li>
                <li class="animate-in">
                  <div class="info letter-container">
                    <h2 class="fade">available hardware</h2>
                  </div>
                  <h4 class="subtitle">We provide only the best hardware for data storage on the market</h4>
                  <div class="lefttop">
                    <img src="../img/additionalphotos/max.png" alt="">
                  </div>
                </li>
                <li class="animate-in">
                  <div class="info letter-container">
                    <h2 class="fade">reliable software</h2>
                  </div>
                  <h4 class="subtitle">Modern technology software at your fingertip</h4>
                  <div class="righttop">
                    <img src="../img/additionalphotos/xl.jpg" alt="">
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- end sequence slider -->
  </section>
  <!-- end featured -->

  <!-- section dailydeals -->
  <section id="dailydeals" class="section gray-bg">
    <div class="container">
      <div class="row">
        <div class="span12">
          <div class="headline">
            <h3><span>Daily Deals</span></h3>
          </div>
        </div>
        <div class="span12">
          <div class="section-intro">
            <p>
              We specialize in data storage .
            </p>
          </div>
        </div>
        <div class="span12">
          <ul class="filter">
            <li class="all active"><a href="#" class="btn btn-color">All categories</a></li>
            <li class="burner"><a href="#" class="btn btn-color">Burners</a></li>
            <li class="dvd"><a href="#" class="btn btn-color">DVD Media</a></li>
            <li class="cdrw"><a href="#" class="btn btn-color">CD-RW Media</a></li>
          </ul>
          <div class="row">
            <ul class="portfolio-area">
              <li class="portfolio-item2" data-id="id-0" data-type="burner">
                <div class="thumb-wrapp">
                  <img src="../img/additionalphotos/burners1.jpg" class="folio-image" alt="">
                  <div class="folio-caption">
                    <h5>Copystars CD-DVD Burner 24X</h5>
                    <span class="folio-link">
									<a href="../img/additionalphotos/burners1.jpg" data-pretty="prettyPhoto" title="Dvd Duplicator tower Is Fully Stand-Alone(No Pc Required), No Software Is needed">
									<i class="icon-rounded  icon-32 icon-zoom-in"></i></a>
									</span>
                  </div>
                </div>
              </li>
              <li class="portfolio-item2" data-id="id-0" data-type="dvd">
                <div class="thumb-wrapp">
                  <img src="../img/additionalphotos/combo.jpg" class="folio-image" alt="">
                  <div class="folio-caption">
                    <h5>24X IDE INTERNAL MULTIBAY</h5>
                    <span class="folio-link">
									<a href="../img/additionalphotos/combo.jpg" data-pretty="prettyPhoto" title="Optical Drive Type	CD-RW DVD-ROM ; Connection	IDE; Dimension	5(W) x 5.1(H) x 0.5(D) inch; Others	ACCESS TIME : 120 MS (DVD), 110 MS (CD); Buffer Size : 2 MB">
									<i class="icon-rounded  icon-32 icon-zoom-in"></i></a>
									</span>
                  </div>
                </div>
              </li>
              <li class="portfolio-item2" data-id="id-0" data-type="burner">
                <div class="thumb-wrapp">
                  <img src="../img/additionalphotos/burners2.jpg" class="folio-image" alt="">
                  <div class="folio-caption">
                    <h5>Produplicator 24X Burner M-Disc</h5>
                    <span class="folio-link">
									<a href="../img/additionalphotos/burners2.jpg" data-pretty="prettyPhoto" title="COMPLETE STANDALONE : no computer or software needed">
									<i class="icon-rounded  icon-32 icon-zoom-in"></i></a>
									</span>
                  </div>
                </div>
              </li>
              <li class="portfolio-item2" data-id="id-0" data-type="dvd">
                <div class="thumb-wrapp">
                  <img src="../img/additionalphotos/du.jpg" class="folio-image" alt="">
                  <div class="folio-caption">
                    <h5>Sony Optiarc IDE 8X</h5>
                    <span class="folio-link">
									<a href="../img/additionalphotos/du.jpg" data-pretty="prettyPhoto" title="This multi-format notebook drive records to DVD±R media at 8x speed and DVD±R DL discs at 4x! It burns to DVD-RW media at 6x and DVD-RAM at 5x!">
									<i class="icon-rounded  icon-32 icon-zoom-in"></i></a>
									</span>
                  </div>
                </div>
              </li>
              <li class="portfolio-item2" data-id="id-0" data-type="cdrw">
                <div class="thumb-wrapp">
                  <img src="../img/additionalphotos/xl.jpg" class="folio-image" alt="">
                  <div class="folio-caption">
                    <h5>Maxell CD-RW 80 Music Case</h5>
                    <span class="folio-link">
									<a href="../img/additionalphotos/xl.jpg" data-pretty="prettyPhoto" title="Recordable cds for music designed for use on home audio recorders.">
									<i class="icon-rounded  icon-32 icon-zoom-in"></i></a>
									</span>
                  </div>
                </div>
              </li>
              <li class="portfolio-item2" data-id="id-0" data-type="dvd">
                <div class="thumb-wrapp">
                  <img src="../img/additionalphotos/sup.jpg" class="folio-image" alt="">
                  <div class="folio-caption">
                    <h5>LG GH24NSC0</h5>
                    <span class="folio-link">
									<a href="../img/additionalphotos/sup.jpg" data-pretty="prettyPhoto" title="Half-height Internal Super Multi Drive, Max. 24X DVD-R Write Speed; Large buffer memory 0.5MB; CD-R/RW, DVD-R/RW/RAM/ +R/RW +/-R DL M-DISC/+M SL read and write compatible, CD Family and DVD-ROM">
									<i class="icon-rounded  icon-32 icon-zoom-in"></i></a>
									</span>
                  </div>
                </div>
              </li>
              <li class="portfolio-item2" data-id="id-0" data-type="burner">
                <div class="thumb-wrapp">
                  <img src="../img/additionalphotos/burners3.jpg" class="folio-image" alt="">
                  <div class="folio-caption">
                    <h5>Acumen Disc CD DVD</h5>
                    <span class="folio-link">
									<a href="../img/additionalphotos/burners3.jpg" data-pretty="prettyPhoto" title="Lifetime Tech Support with 1 year Manufacturer's warranty">
									<i class="icon-rounded  icon-32 icon-zoom-in"></i></a>
									</span>
                  </div>
                </div>
              </li>
              <li class="portfolio-item2" data-id="id-0" data-type="cdrw">
                <div class="thumb-wrapp">
                  <img src="../img/additionalphotos/depot.jpg" class="folio-image" alt="">
                  <div class="folio-caption">
                    <h5>12X CD-RW Disks 10 Pack</h5>
                    <span class="folio-link">
									<a href="../img/additionalphotos/depot.jpg" data-pretty="prettyPhoto" title="Blank CD 16X 700 MB/60Min">
									<i class="icon-rounded  icon-32 icon-zoom-in"></i></a>
									</span>
                  </div>
                </div>
              </li>
              <li class="portfolio-item2" data-id="id-0" data-type="dvd">
                <div class="thumb-wrapp">
                  <img src="../img/additionalphotos/120.jpg" class="folio-image" alt="">
                  <div class="folio-caption">
                    <h5>Sony 10DMW47SS 2X 4.7 GB</h5>
                    <span class="folio-link">
									<a href="../img/additionalphotos/120.jpg" data-pretty="prettyPhoto" title="Stores up to 4.7GB or more than two hours of MPEG2 video.<br>* Compatible for playback with most DVD players and DVD-ROM drives">
									<i class="icon-rounded  icon-32 icon-zoom-in"></i></a>
									</span>
                  </div>
                </div>
              </li>
              <li class="portfolio-item2" data-id="id-0" data-type="cdrw">
                <div class="thumb-wrapp">
                  <img src="../img/additionalphotos/cdr.jpg" class="folio-image" alt="">
                  <div class="folio-caption">
                    <h5>Memorex 40X Digital Audio</h5>
                    <span class="folio-link">
									<a href="../img/additionalphotos/cdr.jpg" data-pretty="prettyPhoto" title="Memorex offers a complete line of CD-RW and CD-R media">
									<i class="icon-rounded  icon-32 icon-zoom-in"></i></a>
									</span>
                  </div>
                </div>
              </li>
              <li class="portfolio-item2" data-id="id-0" data-type="burner">
                <div class="thumb-wrapp">
                  <img src="../img/additionalphotos/burners4.jpg" class="folio-image" alt="">
                  <div class="folio-caption">
                    <h5>PlexCopier 24X SATA</h5>
                    <span class="folio-link">
									<a href="../img/additionalphotos/burners4.jpg" data-pretty="prettyPhoto" title="Complete Standalone Operation: No PC required to operate the duplicator.">
									<i class="icon-rounded  icon-32 icon-zoom-in"></i></a>
									</span>
                  </div>
                </div>
              </li>
              <li class="portfolio-item2" data-id="id-0" data-type="dvd">
                <div class="thumb-wrapp">
                  <img src="../img/additionalphotos/op.jpg" class="folio-image" alt="">
                  <div class="folio-caption">
                    <h5>Panasonic SATA Slot 8X</h5>
                    <span class="folio-link">
									<a href="../img/additionalphotos/op.jpg" data-pretty="prettyPhoto" title="External CD drive that reads CD only. Please note: this does not write CD's or play DVD's; Perfect for users requiring extra cd drive; Suitable for Windows">
									<i class="icon-rounded  icon-32 icon-zoom-in"></i></a>
									</span>
                  </div>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- end section dailydeals -->

 <!-- Section about -->
  <section id="about" class="section">
    <div class="gray-shadow">
    </div>
    <div class="container">
      <div class="row">
        <div class="span12">
          <div class="headline">
            <h3><span>About our company</span></h3>
          </div>
        </div>
      </div>
    </div>

    <div class="container">
      <div class="row">
        <div class="span12">
          <div class="section-intro">
          	<p>
          		need to store data at home, at work, or for the whole of your business enterprise? OceanGate has what you need to tackle the challenges of the information age. our knowledges and resources are pointed to a single goal: to be your preffered source of data storage and information management solutions.
          	</p>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="span6">
          <div class="flexslider">
            <ul class="slides">
              <li>
                <img src="../img/additionalphotos/25.jpg" alt="">
              </li>
              <li>
                <img src="../img/additionalphotos/50cd.jpg" alt="">
              </li>
              <li>
                <img src="../img/additionalphotos/700.jpg" alt="">
              </li>
            </ul>
          </div>
        </div>
        <div class="span6">
          <h3>who we are</h3>
          <p id="whoweare">
            OceanGate Limited is a company established 3 years back which deals in various data storage products right from floppy disk to optical storage devices. It has state of the Art machinery for production of the storage devices/disks which are becoming popular as days pass by due to the excellent quality, fast delivery on purchases and efficient after sales Services.
            <p>
              <div class="dotted_line"></div>
              <h4>Expertise areas</h4>
              <label>Hardware data storage:</label>
              <div class="progress progress-striped progress-success active">
                <div class="bar bar80">
                </div>
              </div>
              <label>Digital storage :</label>
              <div class="progress progress-striped progress-info active">
                <div class="bar bar70">
                </div>
              </div>
        </div>
      </div>
    </div>
  </section>
  <!-- end section about -->

  <!-- section where to buy-->
  <section id ="where" class="section">
 <div class="gray-shadow">
    </div>
    <div class="container">
      <div class="row">
        <div class="span12">
          <div class="headline">
            <h3><span>Where to buy</span></h3>
          </div>
        </div>
      </div>
    </div>

    <div class="container">
      <div class="row">
        <div class="span12">
          <div class="section-intro">
          	<p>
          		Please feel free to choose a location nearest to your residence or office and purchase the product directly rather than having to approach the company. You can also contact the location beforehand for support.
          	</p>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="span6">
        	<h2>
        		please make your purchases at one of these stores
        	</h2><br>
        	<p class="addresses">
        	<b> 
        		Address: 
        	</b>
        		3590 Hershell Hollow Road, Everett, WA, USA<br>
        	<b> 
        		Hotline:</b> (721) 814-7887
        	</p>
        	<p class="addresses">
        	<b> 
        		Address: 
        	</b>
        		3595 Jefferson Street, Norfolk, VA<br>
        	<b> 
        		Hotline:</b> (293) 732-5472
        	</p>
        	<p class="addresses"> 
        		Data Centre Hub Media and Storage experts to help you with data centre needs.
        	</p>
        </div>
        <div class="span6">
        	<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d22864.11283411948!2d-73.96468908098944!3d40.630720240038435!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c24fa5d33f083b%3A0xc80b8f06e177fe62!2sNew+York%2C+NY%2C+USA!5e0!3m2!1sen!2sbg!4v1540447494452" width="100%" height="350" frameborder="0" style="border:0" allowfullscreen></iframe>
        </div>
    </div>
  </section>
  <!-- end section where to buy -->

  <!-- section support-->
  <section id ="support" class="section">
 <div class="gray-shadow">
    </div>
    <div class="container">
      <div class="row">
        <div class="span12">
          <div class="headline">
            <h3><span>Support</span></h3>
          </div>
        </div>
      </div>
    </div>

    <div class="container">
      <div class="row">
        <div class="span12">
          <div class="section-intro">
          	<p>
          		The support centre address and contact details by which the you can directly approach or contact the service centres rather than following the indirect channel.
          	</p>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="span6">
        	<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d22864.11283411948!2d-73.96468908098944!3d40.630720240038435!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c24fa5d33f083b%3A0xc80b8f06e177fe62!2sNew+York%2C+NY%2C+USA!5e0!3m2!1sen!2sbg!4v1540447494452" width="100%" height="350" frameborder="0" style="border:0" allowfullscreen></iframe>
        </div>
        <div class="span6">
        	<h2>
        		please contact or come to these addresses if you need any help or support
        	</h2>
        	<p class="addresses">
        	<b> 
        		Address: 
        	</b>
        		2928 Luke Lane, Oklahoma City, OK, USA<br>
        	<b> 
        		Hotline:</b> (492) 839-2147
        	</p>
        	<br>
        	<p class="addresses">
        	<b> 
        		Address: 
        	</b>
        		4895 Wildwood Street, Akron, OH<br>
        	<b> 
        		Hotline:</b> (247) 844-9346
        	</p>
        	<p class="addresses">  
        		Your FAQS answered and latest drives for your gadgets.
        	</p>
        </div>
  </section>
  <!-- end section support -->

  <footer>
    <div class="verybottom">
      <div class="container">
        <div class="row">
          <div class="span12">
            <div class="aligncenter">
              <div class="logo">
                <a class="brand" href="index.php">
					<img src="../img/additionalphotos/unnamed.png" alt="">
				</a>
              </div>
              <p>Please feel free to reach out to us on social media. We would be honored to assist you</p>
              <div class="social-links">
                <ul class="social-links">
                  <li><a href="#" title="Twitter"><i class="icon-circled icon-64 icon-twitter"></i></a></li>
                  <li><a href="#" title="Facebook"><i class="icon-circled icon-64 icon-facebook"></i></a></li>
                  <li><a href="#" title="Google plus"><i class="icon-circled icon-64 icon-google-plus"></i></a></li>
                  <li><a href="#" title="Linkedin"><i class="icon-circled icon-64 icon-linkedin"></i></a></li>
                  <li><a href="#" title="Pinterest"><i class="icon-circled icon-64 icon-pinterest"></i></a></li>
                </ul>
              </div>
              <p>
                &copy; OceanGate - All right reserved
              </p>
              <div class="credits">
                Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </footer>

  <!-- Javascript Library Files -->
  <script src="../js/jquery.min.js"></script>
  <script src="../js/jquery.easing.js"></script>
  <script src="../js/bootstrap.js"></script>
  <script src="../js/jquery.lettering.js"></script>
  <script src="../js/parallax/jquery.parallax-1.1.3.js"></script>
  <script src="../js/nagging-menu.js"></script>
  <script src="../js/sequence.jquery-min.js"></script>
  <script src="../js/sequencejs-options.sliding-horizontal-parallax.js"></script>
  <script src="../js/portfolio/jquery.quicksand.js"></script>
  <script src="../js/portfolio/setting.js"></script>
  <script src="../js/jquery.scrollTo.js"></script>
  <script src="../js/jquery.nav.js"></script>
  <script src="../js/modernizr.custom.js"></script>
  <script src="../js/prettyPhoto/jquery.prettyPhoto.js"></script>
  <script src="../js/prettyPhoto/setting.js"></script>
  <script src="../js/jquery.flexslider.js"></script>

  <!-- Contact Form JavaScript File -->
  <script src="../contactform/contactform.js"></script>

  <!-- Template Custom Javascript File -->
  <script src="../js/custom.js"></script>

</body>

</html>