<?php
		session_start();
?>
<?php 
    require ("../HeaderAndFooter/customheadlinks.php");
    
    if (isset($_POST['id'])) {
    	$sql = "SELECT * FROM customer WHERE customerid='".$_POST['id']."'";
		$result = $con->query($sql);
		$row = $result->fetch_assoc();
    }
    if (isset($_GET['id'])) {
    	$sql = "SELECT * FROM customer WHERE customerid='".$_GET['id']."'";
		$result = $con->query($sql);
		$row = $result->fetch_assoc();
    }
	

?>

<header>
                <!-- start top -->
                <div id="topnav" class="navbar navbar-fixed-top default" style="background-color:#2a2a2a">
                    <div class="navbar-inner">
                    <div class="container">
                        <div class="logo">
                        <a class="brand" href="index.php" style="padding:1px;"><img style="height:50px;" src="../img/additionalphotos/unnamed.png" alt=""></a>
                        </div>
                        <div class="navigation">
                        <nav>
                            <ul class="nav pull-right">
                            <li><a href="index.php">Home</a></li>
                            <li class="dropdown-submenu">
                                <a href="products.php">
                                    Products
                                </a>
                                <ul class="dropdown-menu">
                                    <li><a tabindex="-1" href="sortproducts.php?sort=4mm and 8mm Data Cartrides">4mm & 8mm Data Cartridges</a></li>
                                    <li><a tabindex="-1" href="sortproducts.php?sort=AIT - Advanced Intelligence Tapes">AIT - Advanced Intelligence Tapes</a></li>
                                    <li><a tabindex="-1" href="sortproducts.php?sort=Burners">Burners</a></li>
                                    <li><a tabindex="-1" href="sortproducts.php?sort=Data Centre Tape & Services">Data Centre Tape & Services</a></li>
                                    <li><a tabindex="-1" href="sortproducts.php?sort=Disc Stakka">Disc Stakka</a></li>
                                    <li class="dropdown-submenu"><a tabindex="-1" href="products.php">Optical Disc</a>
                                        <ul class="dropdown-menu">
                                            <li><a href="sortproducts.php?sort=CD-RW Media">CD-RW Media</a></li>
                                            <li><a href="sortproducts.php?sort=DVD Media">DVD Media</a></li>
                                            <li><a href="sortproducts.php?sort=Forcefield Media">Forcefield Media</a></li>
                                            <li><a href="sortproducts.php?sort=LightScribe Media">LightScribe Media</a></li>
                                            <li><a href="sortproducts.php?sort=Printable Media">Printable Media</a></li>
                                        </ul> 
                                    </li>
                                </ul>
                            </li>
                            <li><a href="contactus.php">Contact Us</a></li>
                            <?php
						
			    			
			                	if (isset($_SESSION['username'])) {
			                		echo "<li class='current'><a href='userprofile.php'>".$_SESSION['username']." </a> </li>";
			                		echo "<li><a href='../actions/logout.php'>Log Out </a> </li>";
			                	}
			                	else {
			                		echo "<li><a href='login.php'>Log In</a></li>";
			                	}
			                 ?>
                            </ul>
                        </nav>
                        </div>
                        <!--/.nav-collapse -->
                    </div>
                    </div>
                </div>
                <!-- end top -->
                </header>
                <?php
					$con = mysqli_connect("localhost", "root","", "oceangate");
                 ?>

 <head>

<hr>
<div class="container bootstrap snippet">
    <div class="row" style="height:100px;">
  		</div>
    <div class="row">
  		<div class="col-sm-3"><!--left col-->
              
<form class="form" action="../actions/updateuseraction.php" enctype="multipart/form-data" method="POST" id="registrationForm">
      <div class="text-center">
        	<?php 
      		if (!empty($row['profilepic'])) {
				echo "<img src='".$row['profilepic']."' class='avatar img-circle img-thumbnail' alt='avatar'>";
      		}
      		else{
				echo "<img src='http://ssl.gstatic.com/accounts/ui/avatar_2x.png' class='avatar img-circle img-thumbnail' alt='avatar'>";
      		}
      	?>
        <h6>Upload a different photo...</h6> 
			<input type="file" name="fileToUpload" id="fileToUpload">
      </div></hr><br>
          
        </div><!--/col-3-->
    	<div class="col-sm-9">
            <ul class="nav nav-tabs">
                <li class="active"><a data-toggle="tab" href="#home">Home</a></li>
              </ul>

              
          <div class="tab-content">
            <div class="tab-pane active" id="home">
                <hr>
                  
                      <div class="form-group">
				<input type="hidden" name="id" value="<?php echo $row['customerid'] ?>">				
                          
                          <div class="col-xs-6">
                              <label for="first_name"><h4>Username</h4></label>
                              <input type="text" class="form-control" name="username" value="<?php echo $row['username'] ?>" >
                          </div>
                      </div>
          
                      <div class="form-group">
                          <div class="col-xs-6">
                             <label for="mobile"><h4>Mobile</h4></label>
                              <input type="text" class="form-control" name="mobile" value="<?php echo $row['phone'] ?>">
                          </div>
                      </div>
                      <div class="form-group">
                          
                          <div class="col-xs-6">
                              <label for="email"><h4>Email</h4></label>
                              <input type="email" class="form-control" name="email" value="<?php echo $row['email'] ?>">
                          </div>
                      </div>
                      <div class="form-group">
                          
                          <div class="col-xs-6">
                              <label for="addres"><h4>Address</h4></label>
                              <input name="address" type="text" class="form-control" value="<?php echo $row['address'] ?>">
                          </div>
                      </div>
                      <div class="form-group">
                          
                          <div class="col-xs-6">
                              <label for="password"><h4>Enter Password To Make Changes</h4></label>
                              <input type="password" class="form-control" name="password">
                          </div>
                      </div>
                      <div class="form-group">
                          
                      </div>
                      <div class="form-group">
                           <div class="col-xs-12">
                                <br>
                              	<button class="btn btn-lg btn-success" type="submit"><i class="glyphicon glyphicon-ok-sign"></i> Save</button>
                               	<button class="btn btn-lg" type="reset"><i class="glyphicon glyphicon-repeat"></i> Reset</button>
                            </div>
                      </div>
              	</form>
              
              <hr>
              
             </div><!--/tab-pane-->

              	</form>
              </div>
               
              </div><!--/tab-pane-->
          </div><!--/tab-content-->

        </div><!--/col-9-->
    </div><!--/row-->

    <?php
    	if (isset($_GET['pass'])) {
    		echo "<script>
    			alert('Incorrect Password');
    		</script>";
    	}
     ?>

    <?php
    	require ("../HeaderAndFooter/customfooter.php");
    	require ("../HeaderAndFooter/customfootlinks.php");
     ?>
