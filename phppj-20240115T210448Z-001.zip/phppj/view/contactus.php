<!DOCTYPE html>
<html>
<head>
	<title>Contact Us</title>
	 <meta charset="utf-8">
  <title>Selecao one page site template with bootstrap</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="">
  <!-- styles -->
  <link href="../css/bootstrap.css" rel="stylesheet">
  <link href="../css/bootstrap-responsive.css" rel="stylesheet">

  <link href="../css/prettyPhoto.css" rel="stylesheet">
  <link href="../font/stylesheet.css" rel="stylesheet">
  <link href="../css/animate.css" rel="stylesheet">
  <link href="../css/flexslider.css" rel="stylesheet">
  <link rel="stylesheet" media="screen" href="../css/sequencejs.css">
  <link href="../css/style.css" rel="stylesheet">
  <link href="../color/default.css" rel="stylesheet">

</head>
<body>
 <header>

    <!-- start top -->
    <div id="topnav" class="navbar navbar-fixed-top default" style="background-color:#2a2a2a; height:80px;">
      <div class="navbar-inner">
        <div class="container">
          <div class="logo">
            <a class="brand" href="index.php" style="padding:1px;"><img style="height:50px;" src="img/additionalphotos/unnamed.png" alt=""></a>
          </div>
          <div class="navigation">
            <nav>
              <ul class="nav pull-right">
                <li><a href="index.php">Home</a></li>
                <li class="dropdown-submenu">
                	<a href="products.php">
                		Products
                	</a>
                	<ul class="dropdown-menu">
                		<li><a tabindex="-1" href="sortproducts.php?sort=48mmDC">4mm & 8mm Data Cartridges</a></li>
                		<li><a tabindex="-1" href="sortproducts.php?sort=AIT">AIT - Advanced Intelligence Tapes</a></li>
                		<li><a tabindex="-1" href="sortproducts.php?sort=BRN">Burners</a></li>
                		<li><a tabindex="-1" href="sortproducts.php?sort=DStac">Disc Stakka</a></li>
                		<li class="dropdown-submenu"><a tabindex="-1" href="#">Optical Disc</a>
            				<ul class="dropdown-menu">
                				<li><a href="sortproducts.php?sort=CRM">CD-RW Media</a></li>
                				<li><a href="sortproducts.php?sort=DVDM">DVD Media</a></li>
                				<li><a href="sortproducts.php?sort=FM">Forcefield Media</a></li>
            				</ul> 
                		</li>
                		<?php
		    				session_start();
		                	if (isset($_SESSION['username'])) {
		                		echo "<li><a href='userprofile.php'>".$_SESSION['username']." </a> </li>";
		                		echo "<li><a href='../actions/logout.php'>Log Out </a> </li>";
		                	}
		                	else {
		                		echo "<li><a href='login.php'>Log In</a></li>";
		                	}
		                 ?>
                            <li><a href="checkout.php">Cart<span class="glyphicon glyphicon-shopping-cart"></a></li>
                	</ul>
                </li>
                <li class="current"><a href="#contact">Contact Us</a></li>
              </ul>
            </nav>
          </div>
          <!--/.nav-collapse -->
        </div>
      </div>
    </div>
    <!-- end top -->
  </header>
  <!-- section contact -->
  <section id="contact" class="section">
    <div class="container">
      <div class="row">
        <div class="span12">
          <div class="headline">
            <h3><span>Get in touch with us</span></h3>
          </div>
        </div>
        <div class="span12">
          <div class="section-intro">
            <p>
              please send us an email if you have any questions or requests. we are always available to assist you
            </p>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="span6">
          <h4><i class="icon-circled icon-32 icon-envelope"></i> Contact form</h4>

          <!-- start contact form -->

          <form action="" method="post" role="form" class="contactForm">
            <div id="sendmessage">Your message has been sent. Thank you!</div>
            <div id="errormessage"></div>

            <ul class="contact-list">
              <li class="form-group">
                <input type="text" name="name" class="form_input" id="name" placeholder="Your Name" data-rule="minlen:4" data-msg="Please enter at least 4 characters">
                <div class="validation"></div>
                <li class="form-group">
                  <input type="email" class="form_input" name="email" id="email" placeholder="Your Email" data-rule="email" data-msg="Please enter a valid email">
                  <div class="validation"></div>
                </li>
                <li class="form-group">
                  <input type="text" class="form_input" name="subject" id="subject" placeholder="Subject" data-rule="minlen:4" data-msg="Please enter at least 8 characters of subject">
                  <div class="validation"></div>
                </li>

                <li class="form-group">
                  <textarea class="form_textarea" name="message" rows="12" data-rule="required" data-msg="Please write something for us" placeholder="Message"></textarea>
                  <div class="validation"></div>
                </li>	
                <li class="last">
                  <button class="btn btn-large btn-theme" type="submit" id="send">Send a message</button>
                </li>
            </ul>
          </form>
          <!-- end contact form -->

        </div>
        <div class="span6">
          <h4><i class="icon-circled icon-32 icon-user"></i> Get in touch with us</h4>
          <p>
            Feel free to ask if you have any question regarding our services or if you just want to say Hello. We would love to hear from you.
          </p>
          <div class="dotted_line">
          </div>
          <p>
            <span><i class="icon-phone"></i> <strong>Phone:</strong> +6221 213 22 21 or +6221 213 22 22</span>
          </p>
          <p>
            <span><i class="icon-comment"></i> <strong>Skype:</strong> hello.oceangate</span>
          </p>
          <p>
            <span><i class="icon-envelope-alt"></i> <strong>Email:</strong> oceangate@eproject.com</span>
          </p>
          <div>
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d22864.11283411948!2d-73.96468908098944!3d40.630720240038435!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c24fa5d33f083b%3A0xc80b8f06e177fe62!2sNew+York%2C+NY%2C+USA!5e0!3m2!1sen!2sbg!4v1540447494452" width="100%" height="350" frameborder="0" style="border:0" allowfullscreen></iframe>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- end section contact -->
    <footer>
    <div class="verybottom">
      <div class="container">
        <div class="row">
          <div class="span12">
            <div class="aligncenter">
              <div class="logo">
                <a class="brand" href="index.php">
								<img src="img/additionalphotos/unnamed.png" alt="">
							</a>
              </div>
              <p>Please feel free to reach out to us on social media. We would be honored to assist you</p>
              <div class="social-links">
                <ul class="social-links">
                  <li><a href="#" title="Twitter"><i class="icon-circled icon-64 icon-twitter"></i></a></li>
                  <li><a href="#" title="Facebook"><i class="icon-circled icon-64 icon-facebook"></i></a></li>
                  <li><a href="#" title="Google plus"><i class="icon-circled icon-64 icon-google-plus"></i></a></li>
                  <li><a href="#" title="Linkedin"><i class="icon-circled icon-64 icon-linkedin"></i></a></li>
                  <li><a href="#" title="Pinterest"><i class="icon-circled icon-64 icon-pinterest"></i></a></li>
                </ul>

              </div>

              <p>
                &copy; Selecao - All right reserved
              </p>
              <div class="credits">
                <!--
                  All the links in the footer should remain intact.
                  You can delete the links only if you purchased the pro version.
                  Licensing information: https://bootstrapmade.com/license/
                  Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=Selecao
                -->
                Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </footer>
  <!-- Javascript Library Files -->
  <script src="../js/jquery.min.js"></script>
  <script src="../js/jquery.easing.js"></script>
  <script src="../js/bootstrap.js"></script>
  <script src="../js/jquery.lettering.js"></script>
  <script src="../js/parallax/jquery.parallax-1.1.3.js"></script>
  <script src="../js/nagging-menu.js"></script>
  <script src="../js/sequence.jquery-min.js"></script>
  <script src="../js/sequencejs-options.sliding-horizontal-parallax.js"></script>
  <script src="../js/portfolio/jquery.quicksand.js"></script>
  <script src="../js/portfolio/setting.js"></script>
  <script src="../js/jquery.scrollTo.js"></script>
  <script src="../js/jquery.nav.js"></script>
  <script src="../js/modernizr.custom.js"></script>
  <script src="../js/prettyPhoto/jquery.prettyPhoto.js"></script>
  <script src="../js/prettyPhoto/setting.js"></script>
  <script src="../js/jquery.flexslider.js"></script>

  <!-- Contact Form JavaScript File -->
  <script src="../contactform/contactform.js"></script>

  <!-- Template Custom Javascript File -->
  <script src="../js/custom.js"></script>
</body>
</html>