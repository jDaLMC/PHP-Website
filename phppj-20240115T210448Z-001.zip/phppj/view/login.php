<?php 
    require ("../HeaderAndFooter/customheadlinks.php");
?>
<header> 
                <!-- start top -->
                <div id="topnav" class="navbar navbar-fixed-top default" style="background-color:#2a2a2a">
                    <div class="navbar-inner">
                    <div class="container">
                        <div class="logo">
                        <a class="brand" href="index.php" style="padding:1px;"><img style="height:50px;" src="../img/additionalphotos/unnamed.png" alt=""></a>
                        </div>
                        <div class="navigation">
                        <nav>
                            <ul class="nav pull-right">
                            <li><a href="index.php">Home</a></li>
                            <li class="dropdown-submenu">
                                <a href="products.php">
                                    Products
                                </a>
                                <ul class="dropdown-menu">
                                    <li><a tabindex="-1" href="sortproducts.php?sort=4mm and 8mm Data Cartrides">4mm & 8mm Data Cartridges</a></li>
                                    <li><a tabindex="-1" href="sortproducts.php?sort=AIT - Advanced Intelligence Tapes">AIT - Advanced Intelligence Tapes</a></li>
                                    <li><a tabindex="-1" href="sortproducts.php?sort=Burners">Burners</a></li>
                                    <li><a tabindex="-1" href="sortproducts.php?sort=Data Centre Tape & Services">Data Centre Tape & Services</a></li>
                                    <li><a tabindex="-1" href="sortproducts.php?sort=Disc Stakka">Disc Stakka</a></li>
                                    <li class="dropdown-submenu"><a tabindex="-1" href="products.php">Optical Disc</a>
                                        <ul class="dropdown-menu">
                                            <li><a href="sortproducts.php?sort=CD-RW Media">CD-RW Media</a></li>
                                            <li><a href="sortproducts.php?sort=DVD Media">DVD Media</a></li>
                                            <li><a href="sortproducts.php?sort=Forcefield Media">Forcefield Media</a></li>
                                            <li><a href="sortproducts.php?sort=LightScribe Media">LightScribe Media</a></li>
                                            <li><a href="sortproducts.php?sort=Printable Media">Printable Media</a></li>
                                        </ul> 
                                    </li>
                                </ul>
                            </li>
                            <li><a href="contactus.php">Contact Us</a></li>
                            <li class="current"><a href="login.php">Log In</a></li>
                            </ul>
                        </nav>
                        </div>
                        <!--/.nav-collapse -->
                    </div>
                    </div>
                </div>
                <!-- end top -->
                </header>
                <?php
					$con = mysqli_connect("localhost", "root","", "oceangate");
                 ?>

<div class="container">
      <div class="row">
        <div class="col-sm-6 offset-sm-3">
          <div class="card">
           
            <div class="card-header">
             Login
            </div>
     <form method="POST" action="../actions/logincheck.php">

            <div class="card-body">
             
			<input type="hidden" name="id">				

                <div class="form-group">
                  <label for="username" class="col-sm-5 control-label">Email:</label>

                  <div class="col-sm-7">
                    <input type="email" name="email" value="" required="required" class="form-control">
                  </div>
                </div>

                <div class="form-group">
                  <label for="password" class="col-sm-5 control-label">Password:</label>
                  <div class="col-sm-7">
                    <input type="password" id="password" name="password" required="required" class="form-control">
                  </div>
                </div>

                <div class="form-group">
			        	<div class="offset-5 col-sm-7">
			          	</div>
		            	</div>

                <div class="form-group">
                  <div class="offset-sm-5 col-sm-7">
                    <input type="submit" id="_submit" name="submit" value="Log In" class="btn btn-primary">
                    <div class="pull-right">
                      <a href="register.php">Sign Up</a>
                    </div>
                  </div>
                </div>
              </form>


            </div>
          </div>
        </div>
      </div>

    </div>

    <?php
    	if (isset($_GET["status"])) {
            echo "<script type='text/javascript'>alert('Incorrect username or password');</script>";
    	}

    	require ("../HeaderAndFooter/customfooter.php");
    	require ("../HeaderAndFooter/customfootlinks.php");
     ?>
    </body>