-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 23, 2019 at 10:23 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.1.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `oceangate`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `adminid` int(20) NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` int(15) NOT NULL,
  `role` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`adminid`, `email`, `password`, `username`, `phone`, `role`) VALUES
(1, 'admin@gmail.com', '12345678', 'main admin', 2147483647, 'web manager');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `typeid` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`typeid`, `type`) VALUES
('48mmDC', '4mm & 8mm Data Cartridges'),
('AIT', 'AIT - Advanced Intelligence Tapes'),
('BRN', 'Burners'),
('CRM', 'CD-RW Media'),
('DStac', 'Disc Stakka'),
('DVDM', 'DVD Media'),
('FM', 'Forcefield Media');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `customerid` int(20) NOT NULL,
  `profilepic` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` int(20) NOT NULL,
  `username` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customerid`, `profilepic`, `address`, `email`, `phone`, `username`, `password`) VALUES
(1, 'img/userprofile/1200px-SNice.svg.png', '8067 Union Street  Winter Springs, FL 327089', 'cadyheplastic@gmail.com', 2147483647, 'Cady Heron', '123456789'),
(2, '', '40 Vine Lane  Sicklerville, NJ 08081', 'jcarty@gmail.com', 555646464, 'Johny Carter', '12345678'),
(3, '', 'none', 'johnsmith@gmail.com', 2147483647, 'John Smith', '12345678'),
(4, '', 'none', 'newguy@gmail.com', 955666231, 'Bill Thompson', '23456781'),
(5, '', 'none', 'newuser@gmail.com', 65546, 'Bill Carry', '12345678');

-- --------------------------------------------------------

--
-- Table structure for table `discount`
--

CREATE TABLE `discount` (
  `discountid` int(20) NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `percentage` int(3) NOT NULL,
  `fromdate` datetime(6) NOT NULL,
  `todate` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `orderdetails`
--

CREATE TABLE `orderdetails` (
  `orderid` int(20) NOT NULL,
  `price` decimal(50,2) NOT NULL,
  `productid` int(20) NOT NULL,
  `quantity` int(11) NOT NULL,
  `totalprice` decimal(50,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orderdetails`
--

INSERT INTO `orderdetails` (`orderid`, `price`, `productid`, `quantity`, `totalprice`) VALUES
(31, '67.12', 8, 1, '67.12'),
(31, '8.98', 7, 1, '8.98');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `orderid` int(20) NOT NULL,
  `customerid` int(20) NOT NULL,
  `total` decimal(30,2) NOT NULL,
  `orderdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`orderid`, `customerid`, `total`, `orderdate`, `status`) VALUES
(31, 1, '76.10', '2019-05-16 06:48:36', 'PENDING');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `productid` int(20) NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `typeid` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` decimal(50,2) NOT NULL,
  `description` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `imgurl` varchar(300) COLLATE utf8mb4_unicode_ci NOT NULL,
  `instock` int(20) NOT NULL DEFAULT '100',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`productid`, `name`, `typeid`, `price`, `description`, `imgurl`, `instock`, `status`) VALUES
(7, 'Sony QG112M D8 8mm Data Cartridge', '48mmDC', '8.98', 'Certified, digital 8mm data cartridge designed for 1,500 passes. 2.5 GB native capacity without data compression. Vertically manufactured tape with 112-meter length', 'img/additionalphotos/qf.jpg', 100, 'Available'),
(8, 'Quantum LG LTO Ultrium-7 Data Cartridge', '48mmDC', '67.12', '15TB Capacity. Weight: 0.260 lbs', 'img/additionalphotos/quantum7.jpg', 100, 'Available'),
(9, 'Sony LTO4 Ultrium Tape Cartridge', '48mmDC', '11.48', ' High-capacity. Advanced Alloy Armored Metal Particle (A3MP). Tracking stability; ultrasonically welded shell.', 'img/additionalphotos/51XqeJodRCL.jpg', 100, 'Available'),
(10, 'HP Ultrium 6.25TB MP RW Data Cartridge', '48mmDC', '23.98', 'Cartridge can write or read data at 1.4 TB per hour. Stores, encrypts and protects up to 3TB on a single cartridge', 'img/additionalphotos/625.jpg', 100, 'Available'),
(11, 'IMATION 8MM D8-160 Data Tape', '48mmDC', '5.99', 'IMATION 8MM D8-160 Data Tape is a 160m Black Watch D8 or DATA 8 tape with up to 7GB Native/Uncompressed capacity and up to 14GB compressed capacity', 'img/additionalphotos/ima.jpg', 100, 'Available'),
(12, 'LG EXATAPE 112m 8MM DATA CARTRIDGE', '48mmDC', '27.35', '8mm Data Cartridge - Box of 4', 'img/additionalphotos/112m.jpg', 100, 'Available'),
(13, 'Sony 10DMW47SS 2X 4.7 GB DVD-RW Disc 10-Pack', 'DVDM', '29.90', 'Stores up to 4.7GB or more than two hours of MPEG2 video. Compatible for playback with most DVD players and DVD-ROM drives', 'img/additionalphotos/120.jpg', 100, 'Available'),
(14, 'Sony 3DMW30R2HC 3-Pack 8cm DVD-RW', 'DVDM', '19.90', 'Stores 1.4GB of data. AccuCORE scratch guard technology is 100x more scratch resistant than standard discs for ideal video protection. Convenient 3-pack. Stores 1.4GB of data', 'img/additionalphotos/dvd.jpg', 100, 'Available'),
(15, 'Maxell DVD-RW Discs', 'DVDM', '13.99', ' Perfect for home video recording, transferring home movies, storing digital pictures, etc. Playback on any DVD drive or player', 'img/additionalphotos/max.jpg', 100, 'Available'),
(16, 'Samsung Pleomax 4X DVD-RW', 'DVDM', '19.99', 'Samsung quality and performance, 4.7GB 5pk Jewel Case', 'img/additionalphotos/1204x.jpg', 100, 'Available'),
(17, 'Fujifilm Media 25302434 3 DVD-R/2 DVD-RW', 'DVDM', '8.99', 'The 1.4GB camcorder media holds up to 30 minutes, 1 Year litmited warrently.', 'img/additionalphotos/dvd5.jpg', 100, 'Available'),
(18, 'Simon DVD-RW Rewritable Disc', 'DVDM', '18.99', 'Capacity Range (Data): 4.70 GB,CDs/DVDs Special Features: Spindle', 'img/additionalphotos/25.jpg', 100, 'Available'),
(19, 'Maxell CD-RW 80 Music Jewel Case', 'CRM', '33.75', 'Recordable cds for music designed for use on home audio recorders.', 'img/additionalphotos/xl.jpg', 100, 'Available'),
(20, '12X CD-RW Disks 10 Pack Slim case', 'CRM', '30.99', 'Blank CD 16X 700 MB/60Min', 'img/additionalphotos/depot.jpg', 100, 'Available'),
(21, 'Memorex 40X Digital Audio Music CD', 'CRM', '13.99', 'Memorex offers a complete line of CD-RW and CD-R media', 'img/additionalphotos/cdr.jpg', 100, 'Available'),
(22, 'Verbatim CD-RW 700MB 4X-12X', 'CRM', '20.99', 'CD-RW 700MB 4X-12X', 'img/additionalphotos/ver.jpg', 100, 'Available'),
(23, 'Maxell CD-RW Rewritable Disc', 'CRM', '5.20', 'Capacity : 80 min (Music), 700.00 MB (Data)', 'img/additionalphotos/700.jpg', 100, 'Available'),
(24, 'Compucessory Products - CD-RW, Branded Surface, 700MB/80 Minute Cap, 12X Speed, 50/PK', 'CRM', '44.70', 'Maximum_Write_Speed - 12x', 'img/additionalphotos/50cd.jpg', 100, 'Available'),
(25, 'Sony SDX1-35C 230M', 'AIT', '12.60', 'Full Size: 1786Ã—1339px ; Aperture: f/4.2 Focal Length: 12.3mm ISO: 64 Shutter: 1/12 sec Camera: FinePix S2750HD', 'img/additionalphotos/35.jpg', 100, 'Available'),
(26, 'Sony SDX4-200C AIT-4 200/520GB', 'AIT', '36.95', 'High storage capacity of up to 520GB compressed data (200GB native) Fast data transfer using efficient Helical Scan technology, up to 24MB/sec sustained native transfer rate', 'img/additionalphotos/520.jpg', 100, 'Available'),
(27, 'Sony TAIT2-80N AIT-2 Turbo Tape Cartridge (80GB/208GB)', 'AIT', '13.99', 'Media Type: AIT-1 Turbo Tape; Native Capacity: 40 GB,Compressed Capacity: 104 GB, Memory Chip:  64k MIC, Mfgr Part ID: Sony TAIT1-40C', 'img/additionalphotos/sony.jpg', 100, 'Available'),
(28, 'SONY AIT-2 SDX2-50CR 50GB data', 'AIT', '13.99', 'The highest amount tender : no; Auction ID : g294643315 ; Return Policy : returns of goods are not accepted', 'img/additionalphotos/ait.jpg', 100, 'Available'),
(29, 'Hp - Ait-3 Ame 100-260gb 230m Data Cartridge (q1999a) Minimum Order 3pcs', 'AIT', '23.98', 'Full Size: 1786Ã—1339px ; Aperture: f/4.2 Focal Length: 12.3mm ISO', 'img/additionalphotos/hp.jpg', 100, 'Available'),
(30, 'HP/COMPAQ - 24X', 'FM', '55.00', 'CD-RW/DVD-ROM COMBO DRIVE(391649-633),SKU HCID01XX Berat Pengiriman 0.5 kg Garansi 3 Bulan, HP/COMPAQ - 24X IDE INTERNAL MULTIBAY CD-RW/DVD-ROM COMBO DRIVE(391649-633)', 'img/additionalphotos/rom.jpg', 100, 'Available'),
(31, 'HP/COMPAQ - 24X IDE INTERNAL MULTIBAY', 'FM', '78.30', 'Optical Drive Type	CD-RW DVD-ROM ; Connection IDE; Dimension 5(W) x 5.1(H) x 0.5(D) inch; Others	ACCESS TIME : 120 MS (DVD), 110 MS (CD); Buffer Size : 2 MB', 'img/additionalphotos/combo.jpg', 100, 'Available'),
(32, 'Sony Optiarc IDE 8X DVDRW Drive - AD-7580', 'FM', '61.60', 'This multi-format notebook drive records to DVDÂ±R media at 8x speed and DVDÂ±R DL discs at 4x! It burns to DVD-RW media at 6x and DVD-RAM at 5x!', 'img/additionalphotos/du.jpg', 100, 'Available'),
(33, 'LG GH24NSC0', 'FM', '36.70', 'Half-height Internal Super Multi Drive, Max. 24X DVD-R Write Speed; Large buffer memory 0.5MB; CD-R/RW, DVD-R/RW/RAM/ +R/RW +/-R DL M-DISC/+M SL read and write compatible, CD Family and DVD-ROM', 'img/additionalphotos/sup.jpg', 100, 'Available'),
(34, 'Blu-ray Disc drive SPD7000BD/00 | Philips', 'FM', '67.30', 'New drive enabling writing on both +R and -R 8.5 GB double layer media;  at 2x speed', 'img/additionalphotos/blu.png', 100, 'Available'),
(35, 'Copystars CD-DVD Burner 24X', 'BRN', '155.91', 'Dvd Duplicator tower Is Fully Stand-Alone(No Pc Required), No Software Is needed\"', 'img/additionalphotos/burners1.jpg', 100, 'Available'),
(36, 'Produplicator 24X Burner M-Disc Support CD DVD', 'BRN', '210.00', 'COMPLETE STANDALONE : no computer or software needed', 'img/additionalphotos/burners2.jpg', 100, 'Available'),
(37, 'PlexCopier 24X SATA 1 to 1 CD DVD', 'BRN', '139.95', 'Complete Standalone Operation: No PC required to operate the duplicator', 'img/additionalphotos/burners4.jpg', 100, 'Available'),
(38, 'Bestduplicator BD-SMG-5T 5 Target 24X SATA DVD', 'BRN', '2329.56', 'Supports DVD+/-R, DVD+/-RW, DVD+/-R Dual Layer, CD-R, CD-RW blank media standards.', 'img/additionalphotos/burners5.jpg', 100, 'Available'),
(39, 'PlexCopier 24X SATA 1 to 5 CD DVD', 'BRN', '200.99', 'Complete Standalone Operation: No PC required to operate the duplicator.', 'img/additionalphotos/burners6.jpg', 100, 'Available'),
(40, 'Imation Disc Stakka - CD/DVD Management Tool', 'DStac', '120.00', 'Automated carousel that stores, protects and retrieves your CDs, DVDs and other discs', 'img/additionalphotos/discstakka.jpg', 100, 'Available'),
(41, 'Driver Imation Disc Stakka Software', 'DStac', '164.00', 'Automated carousel that stores, protects and retrieves your CDs, DVDs and other discs', 'img/additionalphotos/dss.png', 100, 'Available'),
(42, 'Imation Disc Stakka C10AI Disc Carousal CD / DVD Management Stakable Single Unit ', 'DStac', '33.00', 'The item may have some signs of cosmetic wear, but is fully operational and functions as intended. This item may be a floor model or store return that has been used. See the sellerâ€™s listing for full details and description of any imperfections.', 'img/additionalphotos/dsta.jpg', 100, 'AVAILABLE');

-- --------------------------------------------------------

--
-- Table structure for table `productdiscount`
--

CREATE TABLE `productdiscount` (
  `discountid` int(20) NOT NULL,
  `productid` int(20) NOT NULL,
  `ogprice` decimal(30,2) NOT NULL,
  `afterprice` decimal(30,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`adminid`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`typeid`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customerid`);

--
-- Indexes for table `discount`
--
ALTER TABLE `discount`
  ADD PRIMARY KEY (`discountid`);

--
-- Indexes for table `orderdetails`
--
ALTER TABLE `orderdetails`
  ADD KEY `oderid` (`orderid`),
  ADD KEY `productid` (`productid`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`orderid`),
  ADD KEY `ordersforeign` (`customerid`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`productid`),
  ADD KEY `FK_ProductType` (`typeid`);

--
-- Indexes for table `productdiscount`
--
ALTER TABLE `productdiscount`
  ADD KEY `pdcon` (`discountid`),
  ADD KEY `pdconp` (`productid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `adminid` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `customerid` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `discount`
--
ALTER TABLE `discount`
  MODIFY `discountid` int(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `orderid` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `productid` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orderdetails`
--
ALTER TABLE `orderdetails`
  ADD CONSTRAINT `orderdetails_ibfk_1` FOREIGN KEY (`orderid`) REFERENCES `orders` (`orderid`),
  ADD CONSTRAINT `orderdetails_ibfk_2` FOREIGN KEY (`productid`) REFERENCES `product` (`productid`);

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `ordersforeign` FOREIGN KEY (`customerid`) REFERENCES `customer` (`customerid`);

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `FK_ProductType` FOREIGN KEY (`typeid`) REFERENCES `categories` (`typeid`);

--
-- Constraints for table `productdiscount`
--
ALTER TABLE `productdiscount`
  ADD CONSTRAINT `pdcon` FOREIGN KEY (`discountid`) REFERENCES `discount` (`discountid`),
  ADD CONSTRAINT `pdconp` FOREIGN KEY (`productid`) REFERENCES `product` (`productid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
